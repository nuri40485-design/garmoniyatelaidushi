const { Button, IconButton, Card, Badge, Tag, Icon, PearlBullet, SilkDivider, AyahQuote, Tabs, Input, Checkbox, Dialog, Toast } = window.Ds_aa95d3;

function SiteHeader({ onEnroll }) {
  const links = ["Практики", "Курсы", "О Нури", "Отзывы"];
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 20, background: "var(--surface-glass)", backdropFilter: "var(--blur-glass)", borderBottom: "1px solid var(--line-hairline)" }}>
      <div style={{ maxWidth: "var(--container-xl)", margin: "0 auto", padding: "var(--sp-4) var(--sp-6)", display: "flex", alignItems: "center", gap: "var(--sp-6)" }}>
        <div style={{ fontFamily: "var(--font-display)", fontSize: 26, color: "var(--text-strong)", letterSpacing: "-.02em", lineHeight: 1 }}>
          Нури<div style={{ font: "var(--text-eyebrow)", letterSpacing: "var(--ls-caps)", textTransform: "uppercase", color: "var(--aloewood-600)", marginTop: 4 }}>о женском</div>
        </div>
        <nav style={{ display: "flex", gap: "var(--sp-6)", marginLeft: "auto" }}>
          {links.map((l) => <a key={l} href="#" style={{ font: "var(--text-body-sm)", textDecoration: "none" }}>{l}</a>)}
        </nav>
        <Button size="sm" onClick={onEnroll}>Записаться</Button>
      </div>
    </header>
  );
}

function Hero({ onEnroll }) {
  return (
    <section style={{ position: "relative", overflow: "hidden", background: "var(--grad-silk)" }}>
      <div style={{ position: "absolute", inset: 0, backgroundImage: "url(../../assets/textures/silk-rose-wave.webp)", backgroundSize: "cover", backgroundPosition: "center", opacity: 0.45, mixBlendMode: "soft-light" }} />
      <div style={{ position: "absolute", right: "6%", top: "12%", opacity: 0.5 }}><PearlBullet size={120} floating /></div>
      <div style={{ position: "absolute", left: "4%", bottom: "18%", opacity: 0.35 }}><PearlBullet size={56} floating /></div>
      <div style={{ position: "relative", maxWidth: "var(--container-lg)", margin: "0 auto", padding: "var(--sp-9) var(--sp-6) var(--sp-10)", display: "grid", gridTemplateColumns: "minmax(0,1.1fr) minmax(0,.9fr)", gap: "var(--sp-8)", alignItems: "center" }}>
        <div>
          <div className="nuri-eyebrow">Забота о себе · через призму Ислама</div>
          <h1 style={{ margin: "var(--sp-4) 0 var(--sp-5)" }}>Мягкая сила<br />женского тела</h1>
          <p style={{ font: "var(--text-lead)", color: "var(--text-body)", maxWidth: 480 }}>
            Самомассаж через биомеханику, нейрогимнастика и женская гимнастика. Двадцать минут в день — для тела, дыхания и спокойствия.
          </p>
          <div style={{ display: "flex", gap: "var(--gap-inline)", flexWrap: "wrap", marginTop: "var(--sp-5)" }}>
            <Button size="lg" onClick={onEnroll} iconLeft={<Icon name="sparkles" size={18} />}>Записаться на курс</Button>
            <Button size="lg" variant="secondary" iconLeft={<Icon name="play" size={16} />}>Пробный урок</Button>
          </div>
          <div style={{ display: "flex", gap: "var(--sp-6)", marginTop: "var(--sp-7)" }}>
            {[["2 400", "участниц"], ["48", "уроков"], ["20 мин", "в день"]].map(([n, l]) => (
              <div key={l}><div style={{ font: "var(--text-subtitle)", color: "var(--text-strong)" }}>{n}</div><div style={{ font: "var(--text-caption)", color: "var(--aloewood-600)" }}>{l}</div></div>
            ))}
          </div>
        </div>
        <div style={{ position: "relative" }}>
          <img src="../../assets/imagery/pearl-shell-beach.png" alt="" style={{ width: "100%", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-lg)", display: "block" }} />
          <Card padding="sm" style={{ position: "absolute", left: "-8%", bottom: "8%", width: 220 }}>
            <div style={{ display: "flex", alignItems: "center", gap: "var(--sp-3)" }}>
              <PearlBullet size={22} />
              <div><div style={{ font: "var(--text-caption)", color: "var(--text-strong)" }}>Практика дня</div><div style={{ font: "var(--text-caption)", fontWeight: 400, color: "var(--text-muted)" }}>Шея и плечи · 12 мин</div></div>
            </div>
          </Card>
        </div>
      </div>
      <SilkDivider variant="wave" color="var(--pearl-100)" />
    </section>
  );
}

function Practices() {
  const [tab, setTab] = React.useState("all");
  const items = [
    { k: "face", icon: "hand-heart", t: "Самомассаж лица", d: "Биомеханика мягких тканей: скулы, челюсть, шея.", n: "12 уроков" },
    { k: "neuro", icon: "activity", t: "Нейрогимнастика", d: "Простые связки движений для ясной головы.", n: "9 уроков" },
    { k: "gym", icon: "flower-2", t: "Женская гимнастика", d: "Таз, дыхание, осанка — мягко и без надрыва.", n: "18 уроков" },
    { k: "face", icon: "moon-star", t: "Вечерний ритуал", d: "Расслабление перед сном и намазом.", n: "6 уроков" },
    { k: "neuro", icon: "clock", t: "Пять минут", d: "Короткие практики между делами.", n: "14 уроков" },
    { k: "gym", icon: "book-open", t: "Дыхание", d: "Диафрагма, ритм, тишина.", n: "8 уроков" },
  ];
  const shown = tab === "all" ? items : items.filter((i) => i.k === tab);
  return (
    <section style={{ background: "var(--pearl-100)", padding: "var(--sp-9) var(--sp-6)" }}>
      <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: "var(--sp-5)", flexWrap: "wrap" }}>
          <div>
            <div className="nuri-eyebrow">Направления</div>
            <h2 style={{ marginTop: "var(--sp-3)" }}>Три пути к телу</h2>
          </div>
          <Tabs items={[{ value: "all", label: "Все" }, { value: "face", label: "Лицо" }, { value: "neuro", label: "Нейро" }, { value: "gym", label: "Гимнастика" }]} value={tab} onChange={setTab} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))", gap: "var(--gap-card)", marginTop: "var(--sp-6)" }}>
          {shown.map((i) => (
            <Card key={i.t} interactive padding="lg">
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ color: "var(--aloewood-600)" }}><Icon name={i.icon} size={24} /></span>
                <Badge tone="neutral">{i.n}</Badge>
              </div>
              <h4 style={{ margin: "var(--sp-4) 0 var(--sp-2)" }}>{i.t}</h4>
              <p style={{ margin: 0, font: "var(--text-body-sm)", color: "var(--text-muted)" }}>{i.d}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function VerseBand() {
  return (
    <section style={{ background: "var(--grad-silk-deep)", padding: "var(--sp-9) var(--sp-6)" }}>
      <div style={{ maxWidth: "var(--container-md)", margin: "0 auto" }}>
        <AyahQuote tone="dark" arabic="وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً" translation="И Он установил между вами любовь и милосердие." source="Сура Ар-Рум, 21" />
      </div>
    </section>
  );
}

function Program() {
  const rows = [
    ["Неделя 1", "Дыхание и опора", "Учимся дышать диафрагмой, ставим таз и стопы."],
    ["Неделя 2", "Шея и лицо", "Снимаем зажимы челюсти, работаем со скулами."],
    ["Неделя 3", "Нейросвязки", "Кросс-движения, координация, ясность."],
    ["Неделя 4", "Свой ритм", "Собираем личную практику на 20 минут."],
  ];
  return (
    <section style={{ background: "var(--pearl-100)", padding: "var(--sp-9) var(--sp-6)" }}>
      <div style={{ maxWidth: "var(--container-md)", margin: "0 auto" }}>
        <div className="nuri-eyebrow">Программа</div>
        <h2 style={{ marginTop: "var(--sp-3)", marginBottom: "var(--sp-6)" }}>Четыре недели</h2>
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--sp-4)" }}>
          {rows.map(([w, t, d]) => (
            <div key={w} style={{ display: "grid", gridTemplateColumns: "auto 120px minmax(0,1fr)", gap: "var(--sp-5)", alignItems: "start", padding: "var(--sp-4) 0", borderTop: "1px solid var(--line-hairline)" }}>
              <PearlBullet size={14} style={{ marginTop: 8 }} />
              <div style={{ font: "var(--text-caption)", letterSpacing: "var(--ls-caps)", textTransform: "uppercase", color: "var(--aloewood-600)", paddingTop: 4 }}>{w}</div>
              <div><div style={{ font: "var(--text-subtitle)", color: "var(--text-strong)" }}>{t}</div><div style={{ font: "var(--text-body-sm)", color: "var(--text-muted)" }}>{d}</div></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing({ onEnroll }) {
  const [plan, setPlan] = React.useState("year");
  return (
    <section style={{ background: "var(--surface-sunken)", padding: "var(--sp-9) var(--sp-6)" }}>
      <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto", textAlign: "center" }}>
        <div className="nuri-eyebrow">Участие</div>
        <h2 style={{ margin: "var(--sp-3) 0 var(--sp-6)" }}>Выберите ритм</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: "var(--gap-card)", textAlign: "left" }}>
          {[["month", "Месяц", "1 900 ₽", ["Все практики месяца", "Дневник практик", "Чат с наставницей"]],
            ["year", "Год", "14 900 ₽", ["Все 48 уроков", "Живые созвоны раз в месяц", "Разбор осанки по видео", "Доступ навсегда"]],
            ["gift", "В подарок", "2 400 ₽", ["Сертификат на месяц", "Открытка на почту"]]].map(([k, t, p, list]) => (
            <Card key={k} variant={plan === k ? "silk" : "pearl"} padding="lg" interactive onClick={() => setPlan(k)}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ font: "var(--text-subtitle)", color: "var(--text-strong)" }}>{t}</div>
                {k === "year" && <Badge tone="gold">Выгодно</Badge>}
              </div>
              <div style={{ fontFamily: "var(--font-display)", fontSize: 40, color: "var(--text-strong)", margin: "var(--sp-3) 0 var(--sp-4)" }}>{p}</div>
              <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: "var(--sp-3)" }}>
                {list.map((l) => <li key={l} style={{ display: "flex", gap: "var(--sp-3)", alignItems: "center", font: "var(--text-body-sm)", color: plan === k ? "var(--text-on-accent)" : "var(--text-body)" }}><PearlBullet size={10} />{l}</li>)}
              </ul>
              <div style={{ marginTop: "var(--sp-5)" }}>
                <Button fullWidth variant={plan === k ? "dark" : "secondary"} onClick={onEnroll}>Выбрать</Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function SiteFooter() {
  return (
    <footer style={{ background: "var(--grad-dark)", color: "var(--text-on-dark)", padding: "var(--sp-8) var(--sp-6) var(--sp-6)" }}>
      <div style={{ maxWidth: "var(--container-lg)", margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: "var(--sp-6)" }}>
        <div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 26 }}>Нури</div>
          <div style={{ font: "var(--text-body-sm)", color: "var(--mistyrose-300)", marginTop: "var(--sp-2)" }}>О женском. Забота о себе.</div>
        </div>
        {[["Практики", ["Лицо", "Осанка", "Дыхание"]], ["Курсы", ["Четыре недели", "Пробный урок", "Подарочный сертификат"]], ["Связь", ["Telegram", "Instagram", "hello@nuri.ru"]]].map(([t, list]) => (
          <div key={t}>
            <div style={{ font: "var(--text-eyebrow)", letterSpacing: "var(--ls-caps)", textTransform: "uppercase", color: "var(--gold-soft)" }}>{t}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--sp-2)", marginTop: "var(--sp-3)" }}>
              {list.map((l) => <a key={l} href="#" style={{ font: "var(--text-body-sm)", color: "var(--mistyrose-200)", textDecoration: "none" }}>{l}</a>)}
            </div>
          </div>
        ))}
      </div>
      <div style={{ maxWidth: "var(--container-lg)", margin: "var(--sp-6) auto 0", paddingTop: "var(--sp-4)", borderTop: "1px solid rgba(201,168,118,.3)", font: "var(--text-caption)", fontWeight: 400, color: "var(--milktea-300)" }}>© 2026 Нури</div>
    </footer>
  );
}

function EnrollDialog({ open, onClose, onDone }) {
  const [ok, setOk] = React.useState(true);
  return (
    <Dialog open={open} title="Записаться на курс" onClose={onClose} footer={<><Button variant="ghost" onClick={onClose}>Позже</Button><Button onClick={onDone} disabled={!ok}>Отправить</Button></>}>
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--sp-4)" }}>
        <Input label="Ваше имя" placeholder="Например, Амина" />
        <Input label="Telegram или email" placeholder="@nick" />
        <Checkbox label="Согласна на обработку данных" checked={ok} onChange={(e) => setOk(e.target.checked)} />
      </div>
    </Dialog>
  );
}

function Site() {
  const [dialog, setDialog] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  return (
    <div style={{ position: "relative", minHeight: "100%" }}>
      <SiteHeader onEnroll={() => setDialog(true)} />
      <Hero onEnroll={() => setDialog(true)} />
      <Practices />
      <VerseBand />
      <Program />
      <Pricing onEnroll={() => setDialog(true)} />
      <SiteFooter />
      <EnrollDialog open={dialog} onClose={() => setDialog(false)} onDone={() => { setDialog(false); setToast(true); setTimeout(() => setToast(false), 3200); }} />
      {toast && <div style={{ position: "fixed", right: "var(--sp-5)", bottom: "var(--sp-5)", zIndex: 50 }}><Toast tone="success" title="Заявка отправлена" message="Напишем в течение дня, ин ша Аллах." onClose={() => setToast(false)} /></div>}
    </div>
  );
}

Object.assign(window, { Site, SiteHeader, Hero, Practices, VerseBand, Program, Pricing, SiteFooter });
