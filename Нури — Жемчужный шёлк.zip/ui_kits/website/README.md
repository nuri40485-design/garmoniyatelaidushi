# UI kit — marketing site

Course landing page for Нури. `index.html` mounts `Site.jsx`.

Screens / surfaces: sticky glass header, silk hero with floating pearls and a wave divider, filterable practice grid, verse band on deep silk, four-week programme list, three-tier pricing with selectable cards, chocolate footer, enrolment dialog and a success toast.

Interactions: nav tabs filter the practice grid; pricing cards are selectable (selected card switches to the `silk` variant); "Записаться" opens the `Dialog`, submitting shows a `Toast`.

Built only from the system's own primitives (`Button`, `Card`, `Tag`, `Tabs`, `Badge`, `Input`, `Checkbox`, `Dialog`, `Toast`, `Icon`, `PearlBullet`, `SilkDivider`, `AyahQuote`). No source screenshots of a real site existed — layout follows the brand brief's structure rules, not a copied design.
