const { Button, IconButton, Card, Badge, Tag, Icon, PearlBullet, SilkDivider, AyahQuote, Tabs, Switch, Toast, Tooltip } = window.Ds_aa95d3;

const LESSONS = [
  { id: 1, t: "Шея и плечи", d: "Мягкий самомассаж, 12 мин", tag: "Лицо", done: true },
  { id: 2, t: "Кросс-движения", d: "Нейрогимнастика, 8 мин", tag: "Нейро", done: true },
  { id: 3, t: "Дыхание диафрагмой", d: "Основа практики, 10 мин", tag: "Дыхание", done: false },
  { id: 4, t: "Таз и опора", d: "Женская гимнастика, 15 мин", tag: "Гимнастика", done: false },
  { id: 5, t: "Вечерний ритуал", d: "Расслабление, 9 мин", tag: "Лицо", done: false },
];

function StatusBar() {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "var(--sp-3) var(--sp-5) 0", font: "var(--fw-semibold) 13px var(--font-body)", color: "var(--text-strong)" }}>
      <span>9:41</span>
      <span style={{ display: "flex", gap: 6, opacity: .8 }}><Icon name="signal" size={14} /><Icon name="wifi" size={14} /><Icon name="battery-full" size={14} /></span>
    </div>
  );
}

function TabBar({ tab, onTab }) {
  const items = [["home", "house", "Сегодня"], ["lessons", "list", "Практики"], ["diary", "book-open", "Дневник"], ["me", "user", "Я"]];
  return (
    <nav style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 0, padding: "var(--sp-2) var(--sp-3) var(--sp-4)", background: "var(--surface-glass)", backdropFilter: "var(--blur-glass)", borderTop: "1px solid var(--line-hairline)" }}>
      {items.map(([k, ic, label]) => (
        <button key={k} onClick={() => onTab(k)} style={{ border: 0, background: "transparent", cursor: "pointer", display: "grid", justifyItems: "center", gap: 4, minHeight: "var(--tap-min)", color: tab === k ? "var(--sakura-600)" : "var(--text-muted)", transition: "var(--t-color)" }}>
          <Icon name={ic} size={20} />
          <span style={{ font: "var(--fw-medium) 11px var(--font-body)" }}>{label}</span>
        </button>
      ))}
    </nav>
  );
}

function HomeScreen({ onOpen }) {
  return (
    <div style={{ padding: "var(--sp-5)", display: "flex", flexDirection: "column", gap: "var(--sp-5)" }}>
      <div>
        <div className="nuri-eyebrow">Ассаляму алейкум</div>
        <h3 style={{ marginTop: "var(--sp-2)" }}>Сегодня — тело слушаем</h3>
      </div>
      <Card variant="silk" padding="lg" interactive onClick={() => onOpen(LESSONS[2])}>
        <Badge tone="dark">Практика дня</Badge>
        <h4 style={{ margin: "var(--sp-4) 0 var(--sp-2)" }}>Дыхание диафрагмой</h4>
        <p style={{ margin: 0, font: "var(--text-body-sm)", color: "var(--text-on-accent)" }}>10 минут · лежа или сидя</p>
        <div style={{ marginTop: "var(--sp-5)" }}><Button variant="dark" fullWidth iconLeft={<Icon name="play" size={16} />}>Начать</Button></div>
      </Card>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "var(--sp-4)" }}>
        <Card padding="md"><div style={{ font: "var(--text-subtitle)", color: "var(--text-strong)" }}>7</div><div style={{ font: "var(--text-caption)", color: "var(--text-muted)" }}>дней подряд</div></Card>
        <Card padding="md"><div style={{ font: "var(--text-subtitle)", color: "var(--text-strong)" }}>2 / 48</div><div style={{ font: "var(--text-caption)", color: "var(--text-muted)" }}>уроков пройдено</div></Card>
      </div>
      <AyahQuote translation="И Он установил между вами любовь и милосердие." source="Сура Ар-Рум, 21" />
    </div>
  );
}

function LessonsScreen({ onOpen }) {
  const [filter, setFilter] = React.useState("Все");
  const tags = ["Все", "Лицо", "Нейро", "Дыхание", "Гимнастика"];
  const shown = filter === "Все" ? LESSONS : LESSONS.filter((l) => l.tag === filter);
  return (
    <div style={{ padding: "var(--sp-5)", display: "flex", flexDirection: "column", gap: "var(--sp-4)" }}>
      <h3>Практики</h3>
      <div style={{ display: "flex", gap: "var(--gap-inline)", overflowX: "auto", paddingBottom: 4 }}>
        {tags.map((t) => <Tag key={t} selected={filter === t} onClick={() => setFilter(t)}>{t}</Tag>)}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--sp-3)" }}>
        {shown.map((l) => (
          <Card key={l.id} variant="solid" padding="md" interactive onClick={() => onOpen(l)}>
            <div style={{ display: "flex", alignItems: "center", gap: "var(--sp-4)" }}>
              <span style={{ width: 46, height: 46, flex: "none", borderRadius: "var(--radius-md)", background: "var(--grad-silk)", display: "grid", placeItems: "center", color: "var(--choco-700)" }}><Icon name={l.done ? "check" : "play"} size={18} /></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: "var(--fw-semibold) var(--fs-sm)/1.3 var(--font-body)", color: "var(--text-strong)" }}>{l.t}</div>
                <div style={{ font: "var(--text-body-sm)", color: "var(--text-muted)" }}>{l.d}</div>
              </div>
              {l.done ? <Badge tone="success">Пройдено</Badge> : <Badge tone="neutral">{l.tag}</Badge>}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function DiaryScreen() {
  const [tab, setTab] = React.useState("week");
  const days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
  const vals = [12, 8, 15, 0, 10, 20, 6];
  return (
    <div style={{ padding: "var(--sp-5)", display: "flex", flexDirection: "column", gap: "var(--sp-5)" }}>
      <h3>Дневник</h3>
      <Tabs variant="pill" items={[{ value: "week", label: "Неделя" }, { value: "month", label: "Месяц" }]} value={tab} onChange={setTab} />
      <Card padding="lg">
        <div style={{ display: "flex", alignItems: "flex-end", gap: "var(--sp-3)", height: 120 }}>
          {vals.map((v, i) => (
            <div key={i} style={{ flex: 1, display: "grid", justifyItems: "center", gap: 6 }}>
              <div style={{ width: "100%", height: Math.max(v * 4.5, 6), borderRadius: "var(--radius-sm)", background: v ? "var(--grad-accent)" : "var(--surface-sunken)", boxShadow: v ? "var(--shadow-xs)" : "none" }} />
              <span style={{ font: "var(--text-caption)", color: "var(--text-muted)" }}>{days[i]}</span>
            </div>
          ))}
        </div>
      </Card>
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--sp-3)" }}>
        {[["Шея и плечи", "вчера · 12 мин"], ["Кросс-движения", "2 дня назад · 8 мин"]].map(([t, d]) => (
          <div key={t} style={{ display: "flex", alignItems: "center", gap: "var(--sp-3)", padding: "var(--sp-3) 0", borderBottom: "1px solid var(--line-hairline)" }}>
            <PearlBullet />
            <div style={{ flex: 1 }}><div style={{ font: "var(--fw-medium) var(--fs-sm) var(--font-body)", color: "var(--text-strong)" }}>{t}</div><div style={{ font: "var(--text-caption)", fontWeight: 400, color: "var(--text-muted)" }}>{d}</div></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MeScreen() {
  const [rem, setRem] = React.useState(true);
  const [quiet, setQuiet] = React.useState(false);
  return (
    <div style={{ padding: "var(--sp-5)", display: "flex", flexDirection: "column", gap: "var(--sp-5)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "var(--sp-4)" }}>
        <span style={{ width: 64, height: 64, borderRadius: "var(--radius-pearl)", background: "var(--grad-pearl)", boxShadow: "var(--pearl-shadow)" }} />
        <div><div style={{ font: "var(--text-subtitle)", color: "var(--text-strong)" }}>Амина</div><div style={{ font: "var(--text-caption)", color: "var(--text-muted)" }}>Годовой доступ · до 09.2027</div></div>
      </div>
      <Card padding="lg" style={{ display: "flex", flexDirection: "column", gap: "var(--sp-4)" }}>
        <Switch label="Напоминания о практике" checked={rem} onChange={(e) => setRem(e.target.checked)} />
        <Switch label="Тихий режим в намаз" checked={quiet} onChange={(e) => setQuiet(e.target.checked)} />
      </Card>
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--sp-2)" }}>
        {[["Чат с наставницей", "message-circle"], ["Мои сохранённые", "bookmark"], ["Поддержка", "life-buoy"]].map(([t, ic]) => (
          <button key={t} style={{ display: "flex", alignItems: "center", gap: "var(--sp-4)", minHeight: "var(--tap-min)", padding: "0 var(--sp-2)", border: 0, background: "transparent", cursor: "pointer", font: "var(--text-body-sm)", color: "var(--text-body)" }}>
            <span style={{ color: "var(--aloewood-600)" }}><Icon name={ic} size={18} /></span>{t}
            <span style={{ marginLeft: "auto", color: "var(--milktea-300)" }}><Icon name="chevron-right" size={16} /></span>
          </button>
        ))}
      </div>
    </div>
  );
}

function PlayerScreen({ lesson, onBack, onDone }) {
  const [playing, setPlaying] = React.useState(true);
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ position: "relative", height: 300, backgroundImage: "url(../../assets/imagery/roses-pearls-gold.jpg)", backgroundSize: "cover", backgroundPosition: "center" }}>
        <div style={{ position: "absolute", inset: 0, background: "var(--grad-veil)" }} />
        <div style={{ position: "absolute", top: "var(--sp-4)", left: "var(--sp-4)", right: "var(--sp-4)", display: "flex", justifyContent: "space-between" }}>
          <IconButton name="chevron-left" variant="glass" label="Назад" onClick={onBack} />
          <IconButton name="bookmark" variant="glass" label="Сохранить" />
        </div>
        <div style={{ position: "absolute", left: "var(--sp-5)", right: "var(--sp-5)", bottom: "var(--sp-5)", color: "var(--pearl-100)" }}>
          <div style={{ font: "var(--text-eyebrow)", letterSpacing: "var(--ls-caps)", textTransform: "uppercase", color: "var(--mistyrose-300)" }}>{lesson.tag}</div>
          <div style={{ font: "var(--text-title)", marginTop: "var(--sp-2)" }}>{lesson.t}</div>
        </div>
      </div>
      <div style={{ padding: "var(--sp-5)", display: "flex", flexDirection: "column", gap: "var(--sp-5)", flex: 1 }}>
        <div>
          <div style={{ height: 6, borderRadius: "var(--radius-pill)", background: "var(--surface-sunken)", overflow: "hidden" }}>
            <div style={{ width: "38%", height: "100%", background: "var(--grad-accent)" }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", font: "var(--text-caption)", color: "var(--text-muted)", marginTop: "var(--sp-2)" }}><span>3:48</span><span>10:00</span></div>
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "var(--sp-5)" }}>
          <IconButton name="rotate-ccw" label="Назад 10 секунд" />
          <IconButton name={playing ? "pause" : "play"} size="lg" variant="primary" label="Пауза" onClick={() => setPlaying(!playing)} />
          <Tooltip content="Отметить пройденным"><IconButton name="check" label="Готово" onClick={onDone} /></Tooltip>
        </div>
        <div>
          <div className="nuri-eyebrow">Что делаем</div>
          <ul style={{ listStyle: "none", margin: "var(--sp-3) 0 0", padding: 0, display: "flex", flexDirection: "column", gap: "var(--sp-3)" }}>
            {["Ладони на нижние рёбра, вдох в стороны", "Выдох дольше вдоха, без напряжения", "Шесть циклов, затем отдых"].map((t) => (
              <li key={t} style={{ display: "flex", gap: "var(--sp-3)", alignItems: "center", font: "var(--text-body-sm)", color: "var(--text-body)" }}><PearlBullet size={10} />{t}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [tab, setTab] = React.useState("home");
  const [lesson, setLesson] = React.useState(null);
  const [toast, setToast] = React.useState(false);
  const screens = { home: <HomeScreen onOpen={setLesson} />, lessons: <LessonsScreen onOpen={setLesson} />, diary: <DiaryScreen />, me: <MeScreen /> };
  return (
    <div style={{ width: 390, height: 844, margin: "0 auto", position: "relative", display: "flex", flexDirection: "column", overflow: "hidden", background: "var(--grad-page)", borderRadius: 44, border: "1px solid var(--line-soft)", boxShadow: "var(--shadow-lg)" }}>
      {!lesson && <StatusBar />}
      <div style={{ flex: 1, overflowY: "auto" }}>
        {lesson ? <PlayerScreen lesson={lesson} onBack={() => setLesson(null)} onDone={() => { setLesson(null); setToast(true); setTimeout(() => setToast(false), 3000); }} /> : screens[tab]}
      </div>
      {!lesson && <TabBar tab={tab} onTab={setTab} />}
      {toast && <div style={{ position: "absolute", left: "var(--sp-4)", right: "var(--sp-4)", top: "var(--sp-6)", zIndex: 30 }}><Toast tone="success" title="Практика завершена" message="Отмечено в дневнике." onClose={() => setToast(false)} /></div>}
    </div>
  );
}

Object.assign(window, { App, HomeScreen, LessonsScreen, DiaryScreen, MeScreen, PlayerScreen, TabBar, StatusBar });
