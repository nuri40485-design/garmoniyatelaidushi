# UI kit — practice app

390×844 mobile app for daily practice. `index.html` mounts `App.jsx`.

Screens: **Сегодня** (practice of the day on a silk card, streak stats, verse), **Практики** (tag-filtered lesson list), **Дневник** (weekly minutes chart + history), **Я** (profile, switches, menu rows), and the **player** (full-bleed image with veil, progress, transport controls, three practice steps).

Interactions: bottom tab bar switches screens; tapping any lesson opens the player; the check control marks the lesson done, returns to the list and raises a success toast.

Uses `Card` `variant="solid"` inside lists (glass on glass muddies) and `glass` icon buttons over imagery.
