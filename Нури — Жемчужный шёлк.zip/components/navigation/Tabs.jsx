import React from "react";

export function Tabs({ items = [], value, onChange, variant = "underline" }) {
  const active = value ?? items[0]?.value;
  const isPill = variant === "pill";
  return (
    <div
      role="tablist"
      style={{
        display: "flex", gap: isPill ? "var(--sp-1)" : "var(--sp-6)", alignItems: "center",
        padding: isPill ? "var(--sp-1)" : 0,
        background: isPill ? "var(--surface-sunken)" : "transparent",
        borderRadius: isPill ? "var(--radius-pill)" : 0,
        borderBottom: isPill ? "none" : "1px solid var(--line-hairline)",
        overflowX: "auto",
      }}
    >
      {items.map((it) => {
        const on = it.value === active;
        return (
          <button
            key={it.value}
            role="tab"
            aria-selected={on}
            onClick={() => onChange && onChange(it.value)}
            style={{
              border: 0, cursor: "pointer", whiteSpace: "nowrap", transition: "var(--t-all)",
              font: `${on ? "var(--fw-semibold)" : "var(--fw-medium)"} var(--fs-sm)/1 var(--font-body)`,
              color: on ? (isPill ? "var(--text-on-accent)" : "var(--text-strong)") : "var(--text-muted)",
              padding: isPill ? "0 var(--sp-5)" : "0 0 var(--sp-3)",
              minHeight: isPill ? 38 : 34,
              background: isPill && on ? "var(--grad-accent)" : "transparent",
              borderRadius: isPill ? "var(--radius-pill)" : 0,
              boxShadow: isPill && on ? "var(--shadow-xs)" : "none",
              borderBottom: isPill ? "none" : `2px solid ${on ? "var(--sakura-500)" : "transparent"}`,
              marginBottom: isPill ? 0 : -1,
            }}
          >
            {it.label}
          </button>
        );
      })}
    </div>
  );
}
