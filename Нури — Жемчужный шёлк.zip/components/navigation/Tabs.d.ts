import * as React from "react";
/** Horizontal section switcher. */
export interface TabsProps {
  items: { value: string; label: string }[];
  value?: string;
  onChange?: (value: string) => void;
  /** underline = page sections; pill = in-card segmented control */
  variant?: "underline" | "pill";
}
export declare function Tabs(props: TabsProps): JSX.Element;
