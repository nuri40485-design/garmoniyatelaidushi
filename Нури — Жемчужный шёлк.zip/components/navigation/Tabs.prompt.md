Switches between sibling views (course modules, app sections).

```jsx
<Tabs variant="pill" value={tab} onChange={setTab}
  items={[{value:"all",label:"Все"},{value:"face",label:"Лицо"}]} />
```

`underline` for page-level sections, `pill` inside a Card.
