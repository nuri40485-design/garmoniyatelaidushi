import React from "react";

export function Checkbox({ label, checked, onChange, disabled = false, ...rest }) {
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: "var(--sp-3)", minHeight: "var(--tap-min)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1 }}>
      <input type="checkbox" checked={checked} onChange={onChange} disabled={disabled} style={{ position: "absolute", opacity: 0, width: 0, height: 0 }} {...rest} />
      <span
        style={{
          width: 22, height: 22, flex: "none", display: "grid", placeItems: "center",
          borderRadius: "var(--radius-xs)",
          background: checked ? "var(--grad-accent)" : "var(--surface-raised)",
          border: checked ? "1px solid transparent" : "1px solid var(--line-soft)",
          boxShadow: checked ? "var(--shadow-xs)" : "var(--inset-well)",
          transition: "var(--t-all)",
        }}
      >
        <span style={{ width: 10, height: 6, borderLeft: "2px solid var(--text-on-accent)", borderBottom: "2px solid var(--text-on-accent)", transform: "rotate(-45deg) translate(0,-1px)", opacity: checked ? 1 : 0, transition: "opacity var(--dur-quick) var(--ease-silk)" }} />
      </span>
      {label && <span style={{ font: "var(--text-body-sm)", color: "var(--text-body)" }}>{label}</span>}
    </label>
  );
}
