Single-line or multiline text entry. The well has an inset shadow (light falls into it); focus paints a sakura ring.

```jsx
<Input label="Ваше имя" placeholder="Например, Амина" />
<Input label="Email" error="Проверьте адрес" />
<Input label="Вопрос наставнице" multiline />
```
