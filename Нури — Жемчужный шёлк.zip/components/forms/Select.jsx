import React from "react";

export function Select({ label, hint, options = [], style, ...rest }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: "var(--sp-2)", width: "100%" }}>
      {label && <span style={{ font: "var(--text-caption)", color: "var(--text-muted)", letterSpacing: ".04em" }}>{label}</span>}
      <span className="nuri-select" style={{ position: "relative", display: "block" }}>
        <style>{`.nuri-select select{appearance:none;width:100%;min-height:var(--control-h-md);padding:0 var(--sp-7) 0 var(--sp-4);background:var(--surface-raised);border:1px solid var(--line-soft);border-radius:var(--radius-pill);box-shadow:var(--inset-well);font:var(--text-body-sm);color:var(--text-strong);cursor:pointer;transition:var(--t-all)}.nuri-select select:focus{outline:none;border-color:var(--sakura-500);box-shadow:var(--ring-focus)}.nuri-select .nuri-caret{position:absolute;right:var(--sp-5);top:50%;width:8px;height:8px;margin-top:-6px;border-right:1.5px solid var(--aloewood-600);border-bottom:1.5px solid var(--aloewood-600);transform:rotate(45deg);pointer-events:none}`}</style>
        <select style={style} {...rest}>
          {options.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <span className="nuri-caret" />
      </span>
      {hint && <span style={{ font: "var(--text-caption)", fontWeight: "var(--fw-regular)", color: "var(--text-muted)" }}>{hint}</span>}
    </label>
  );
}
