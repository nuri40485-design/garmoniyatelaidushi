Dropdown for 4+ mutually exclusive options (level, cycle day, language).

```jsx
<Select label="Уровень" options={[{value:"1",label:"Начальный"},{value:"2",label:"Продолжающий"}]} />
```
