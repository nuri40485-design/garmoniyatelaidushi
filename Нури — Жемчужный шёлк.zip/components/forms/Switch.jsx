import React from "react";

export function Switch({ label, checked = false, onChange, disabled = false, ...rest }) {
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: "var(--sp-4)", minHeight: "var(--tap-min)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1 }}>
      <input type="checkbox" role="switch" checked={checked} onChange={onChange} disabled={disabled} style={{ position: "absolute", opacity: 0, width: 0, height: 0 }} {...rest} />
      <span style={{ width: 52, height: 30, flex: "none", padding: 3, borderRadius: "var(--radius-pill)", background: checked ? "var(--grad-accent)" : "var(--surface-sunken)", boxShadow: checked ? "var(--shadow-xs)" : "var(--inset-well)", transition: "var(--t-all)" }}>
        <span style={{ display: "block", width: 24, height: 24, borderRadius: "var(--radius-pearl)", background: "var(--grad-pearl)", boxShadow: "var(--pearl-shadow)", transform: checked ? "translateX(22px)" : "none", transition: "transform var(--dur-base) var(--ease-silk)" }} />
      </span>
      {label && <span style={{ font: "var(--text-body-sm)", color: "var(--text-body)" }}>{label}</span>}
    </label>
  );
}
