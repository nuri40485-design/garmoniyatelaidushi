One-of-many choice, 2–4 options. More than that, use `Select`.

```jsx
<Radio name="plan" label="Месяц" checked={plan==="m"} onChange={()=>setPlan("m")} />
```

The checked mark is a pearl bead — this is the brand's signature selection cue.
