import * as React from "react";
/** Text field with label, hint and error slots. Pill-shaped unless multiline. */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  /** Replaces hint and turns the border red */
  error?: string;
  size?: "sm" | "md" | "lg";
  prefix?: React.ReactNode;
  suffix?: React.ReactNode;
  /** Renders a 4-row textarea with a 16px radius */
  multiline?: boolean;
}
export declare function Input(props: InputProps): JSX.Element;
