import * as React from "react";
/** Native select styled to match Input, with a hairline chevron. */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: string;
  options?: { value: string; label: string }[];
}
export declare function Select(props: SelectProps): JSX.Element;
