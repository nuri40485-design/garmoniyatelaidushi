import React from "react";

export function Input({ label, hint, error, size = "md", prefix, suffix, multiline = false, style, ...rest }) {
  const h = size === "sm" ? "var(--control-h-sm)" : size === "lg" ? "var(--control-h-lg)" : "var(--control-h-md)";
  const Field = multiline ? "textarea" : "input";
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: "var(--sp-2)", width: "100%" }}>
      {label && <span style={{ font: "var(--text-caption)", color: "var(--text-muted)", letterSpacing: ".04em" }}>{label}</span>}
      <span
        className="nuri-field"
        style={{
          display: "flex", alignItems: "center", gap: "var(--sp-3)",
          minHeight: multiline ? undefined : h, padding: multiline ? "var(--sp-3) var(--sp-4)" : "0 var(--sp-4)",
          background: "var(--surface-raised)", borderRadius: multiline ? "var(--radius-md)" : "var(--radius-pill)",
          border: error ? "1px solid var(--danger)" : "1px solid var(--line-soft)",
          boxShadow: "var(--inset-well)", transition: "var(--t-all)",
        }}
      >
        <style>{`.nuri-field:focus-within{border-color:var(--sakura-500);box-shadow:var(--ring-focus)}.nuri-field input,.nuri-field textarea{flex:1;min-width:0;border:0;outline:0;background:transparent;font:var(--text-body-sm);color:var(--text-strong);resize:vertical}.nuri-field input::placeholder,.nuri-field textarea::placeholder{color:var(--milktea-300)}`}</style>
        {prefix}
        <Field rows={multiline ? 4 : undefined} style={style} {...rest} />
        {suffix}
      </span>
      {(hint || error) && (
        <span style={{ font: "var(--text-caption)", fontWeight: "var(--fw-regular)", color: error ? "var(--danger)" : "var(--text-muted)" }}>{error || hint}</span>
      )}
    </label>
  );
}
