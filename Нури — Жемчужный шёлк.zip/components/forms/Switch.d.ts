import * as React from "react";
/** On/off toggle; the knob is a pearl bead that glides on a satin track. */
export interface SwitchProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  checked?: boolean;
  disabled?: boolean;
}
export declare function Switch(props: SwitchProps): JSX.Element;
