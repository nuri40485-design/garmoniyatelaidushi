Immediate-effect setting (reminders, sound, private mode).

```jsx
<Switch label="Напоминания о практике" checked={on} onChange={e=>setOn(e.target.checked)} />
```

Never use a Switch for form submission — that's a Checkbox.
