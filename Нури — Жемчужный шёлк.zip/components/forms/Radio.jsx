import React from "react";

export function Radio({ label, checked, onChange, name, value, disabled = false, ...rest }) {
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: "var(--sp-3)", minHeight: "var(--tap-min)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.5 : 1 }}>
      <input type="radio" name={name} value={value} checked={checked} onChange={onChange} disabled={disabled} style={{ position: "absolute", opacity: 0, width: 0, height: 0 }} {...rest} />
      <span style={{ width: 22, height: 22, flex: "none", display: "grid", placeItems: "center", borderRadius: "var(--radius-pearl)", background: checked ? "var(--grad-pearl)" : "var(--surface-raised)", border: checked ? "1px solid var(--line-gold)" : "1px solid var(--line-soft)", boxShadow: checked ? "var(--pearl-shadow)" : "var(--inset-well)", transition: "var(--t-all)" }}>
        <span style={{ width: 8, height: 8, borderRadius: "var(--radius-pearl)", background: "var(--sakura-600)", opacity: checked ? 1 : 0, transition: "opacity var(--dur-quick) var(--ease-silk)" }} />
      </span>
      {label && <span style={{ font: "var(--text-body-sm)", color: "var(--text-body)" }}>{label}</span>}
    </label>
  );
}
