import * as React from "react";
/** Single choice. Selected state renders as a small pearl bead. */
export interface RadioProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  checked?: boolean;
  name?: string;
  value?: string;
  disabled?: boolean;
}
export declare function Radio(props: RadioProps): JSX.Element;
