Multi-select choice and lesson-completion ticks.

```jsx
<Checkbox label="Согласна с условиями" checked={ok} onChange={e => setOk(e.target.checked)} />
```

The whole label is a 44px tap target.
