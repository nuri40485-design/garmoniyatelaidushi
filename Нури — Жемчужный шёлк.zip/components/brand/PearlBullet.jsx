import React from "react";

export function PearlBullet({ size = 14, floating = false, style, ...rest }) {
  return (
    <span
      {...rest}
      aria-hidden="true"
      style={{
        width: size, height: size, flex: "none", display: "inline-block",
        borderRadius: "var(--radius-pearl)", background: "var(--grad-pearl)",
        boxShadow: "var(--pearl-shadow)",
        animation: floating ? "nuri-float 6s var(--ease-in-out-soft) infinite" : undefined,
        ...style,
      }}
    />
  );
}
