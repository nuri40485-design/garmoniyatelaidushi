Every section boundary uses one of these three — flat straight borders between sections are off-brand.

```jsx
<SilkDivider variant="wave" color="var(--surface-page)" />
<SilkDivider variant="pearlRow" />
```

`color` must match the section that follows, since the wave is drawn as that section bleeding upward.
