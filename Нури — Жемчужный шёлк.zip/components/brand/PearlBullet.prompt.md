Replaces every disc bullet in the brand. Also the only approved free-floating decoration (2–3 per screen, `floating`, 6–18% opacity siblings behind content).

```jsx
<li style={{display:"flex",gap:"var(--sp-3)",alignItems:"center"}}>
  <PearlBullet /> Мягкий самомассаж лица
</li>
```
