import * as React from "react";
/** The brand's signature bead: a radial-gradient pearl with a top-left highlight. Use as list marker or floating decor. */
export interface PearlBulletProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** px diameter — 8/14/22 for bullets, 40–120 for decor */
  size?: number;
  /** Slow 6s vertical drift, for background decor only */
  floating?: boolean;
}
export declare function PearlBullet(props: PearlBulletProps): JSX.Element;
