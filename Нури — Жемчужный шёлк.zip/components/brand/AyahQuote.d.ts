import * as React from "react";
/**
 * Qur'anic verse or hadith block: Arabic in Amiri, translation in the display serif, source in caps.
 * @startingPoint section="Brand" subtitle="Verse block with Arabic, translation, source" viewport="700x320"
 */
export interface AyahQuoteProps {
  /** Arabic text, rendered RTL in Amiri */
  arabic?: string;
  /** Russian translation */
  translation?: string;
  /** Reference, e.g. "Сура Ар-Рум, 21" */
  source?: string;
  tone?: "light" | "dark";
}
export declare function AyahQuote(props: AyahQuoteProps): JSX.Element;
