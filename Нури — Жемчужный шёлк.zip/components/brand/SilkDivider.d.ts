import * as React from "react";
/** Section separator — silk wave, gold hairline, or a pearl row. Never a plain straight rule. */
export interface SilkDividerProps {
  variant?: "wave" | "gold" | "pearlRow";
  /** Wave only: mirrors the curve for a bottom edge */
  flip?: boolean;
  /** Wave height in px, default 64 */
  height?: number;
  /** Wave fill — set to the colour of the section BELOW */
  color?: string;
}
export declare function SilkDivider(props: SilkDividerProps): JSX.Element;
