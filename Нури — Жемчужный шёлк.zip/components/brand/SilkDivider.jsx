import React from "react";

export function SilkDivider({ variant = "wave", flip = false, height = 64, color = "var(--surface-page)" }) {
  if (variant === "gold") {
    return <hr style={{ height: 1, border: 0, margin: 0, background: "var(--grad-gold-line)" }} />;
  }
  if (variant === "pearlRow") {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "var(--sp-3)", padding: "var(--sp-5) 0" }}>
        <span style={{ flex: 1, height: 1, background: "var(--grad-gold-line)" }} />
        {[10, 14, 10].map((d, i) => (
          <span key={i} style={{ width: d, height: d, borderRadius: "var(--radius-pearl)", background: "var(--grad-pearl)", boxShadow: "var(--pearl-shadow)" }} />
        ))}
        <span style={{ flex: 1, height: 1, background: "var(--grad-gold-line)" }} />
      </div>
    );
  }
  return (
    <div style={{ height, overflow: "hidden", lineHeight: 0, transform: flip ? "rotate(180deg)" : undefined }}>
      <svg viewBox="0 0 1440 64" preserveAspectRatio="none" style={{ width: "100%", height: "100%", display: "block" }}>
        <path d="M0 40 C 240 -10 480 70 720 34 C 960 0 1200 62 1440 24 L1440 64 L0 64 Z" fill={color} />
      </svg>
    </div>
  );
}
