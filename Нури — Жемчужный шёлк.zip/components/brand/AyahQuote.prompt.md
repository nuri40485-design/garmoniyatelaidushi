The one place Arabic script appears. Use for a verse or hadith that frames a practice — at most one per screen.

```jsx
<AyahQuote tone="dark"
  arabic="وَجَعَلَ بَيْنَكُم مَّوَدَّةً وَرَحْمَةً"
  translation="И Он установил между вами любовь и милосердие."
  source="Сура Ар-Рум, 21" />
```

Always give the source. Never decorate the Arabic line with gradients, shadows, or animation.
