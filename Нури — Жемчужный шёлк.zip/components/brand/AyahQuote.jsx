import React from "react";

export function AyahQuote({ arabic, translation, source, tone = "light" }) {
  const dark = tone === "dark";
  return (
    <figure style={{ margin: 0, padding: "var(--pad-card-lg)", borderRadius: "var(--radius-lg)", background: dark ? "var(--grad-dark)" : "var(--surface-card)", backdropFilter: dark ? undefined : "var(--blur-glass)", border: dark ? "1px solid rgba(201,168,118,.35)" : "var(--border-gold)", boxShadow: "var(--shadow-md)", textAlign: "center" }}>
      {arabic && (
        <p className="nuri-arabic" style={{ margin: "0 0 var(--sp-4)", color: dark ? "var(--pearl-100)" : "var(--text-strong)" }}>{arabic}</p>
      )}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "var(--sp-3)", margin: "0 0 var(--sp-4)" }}>
        <span style={{ width: 44, height: 1, background: "var(--grad-gold-line)" }} />
        <span style={{ width: 10, height: 10, borderRadius: "var(--radius-pearl)", background: "var(--grad-pearl)", boxShadow: "var(--pearl-shadow)" }} />
        <span style={{ width: 44, height: 1, background: "var(--grad-gold-line)" }} />
      </div>
      {translation && (
        <blockquote style={{ margin: 0, font: "var(--fw-regular) var(--fs-d4)/1.45 var(--font-display)", fontStyle: "italic", color: dark ? "var(--pearl-100)" : "var(--text-strong)" }}>{translation}</blockquote>
      )}
      {source && (
        <figcaption style={{ marginTop: "var(--sp-4)", font: "var(--text-caption)", letterSpacing: "var(--ls-caps)", textTransform: "uppercase", color: dark ? "var(--gold-soft)" : "var(--aloewood-600)" }}>{source}</figcaption>
      )}
    </figure>
  );
}
