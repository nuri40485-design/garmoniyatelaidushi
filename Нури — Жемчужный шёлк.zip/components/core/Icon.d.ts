import * as React from "react";
/** Line icon from the Lucide set, masked to currentColor. */
export interface IconProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Lucide icon id, e.g. "heart", "moon-star", "sparkles", "play" */
  name?: string;
  /** px box size — 16 / 20 / 24 are the brand steps */
  size?: number;
  /** "light" renders at 75% opacity for decorative use */
  strokeWidth?: "regular" | "light";
}
export declare function Icon(props: IconProps): JSX.Element;
