Every grouped block sits in a Card. `pearl` (translucent + gold hairline) is the default; `silk` for one highlighted offer per page; `dark` for testimonial or verse blocks; `solid` inside app screens where glass over glass would muddy.

```jsx
<Card variant="pearl" padding="lg" interactive>
  <h4>Самомассаж лица</h4>
  <p>12 уроков по биомеханике мягких тканей.</p>
</Card>
```

Radius is `--radius-lg` (24px); use `padding="none"` only when the card holds a full-bleed image at the top.
