Non-interactive status pill, 24px tall.

```jsx
<Badge tone="gold">Новый курс</Badge>
<Badge tone="success">Пройдено</Badge>
```

For selectable filters use `Tag` instead.
