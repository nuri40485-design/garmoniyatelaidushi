import * as React from "react";
/**
 * Primary call-to-action. Satin gradient fill with letterpress relief and a hover shimmer.
 * @startingPoint section="Core" subtitle="Satin CTA button in four variants" viewport="700x150"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = sakura→rose-gold satin; secondary = pearl with gold hairline; ghost = bare text; dark = chocolate silk */
  variant?: "primary" | "secondary" | "ghost" | "dark";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  fullWidth?: boolean;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
  /** Render as another element, e.g. "a" for links */
  as?: "button" | "a";
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
