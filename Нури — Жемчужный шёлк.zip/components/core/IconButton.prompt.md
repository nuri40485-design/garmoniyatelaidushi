Icon-only action — always circular (it reads as a pearl). Use `glass` over imagery, `secondary` on pearl surfaces.

```jsx
<IconButton name="play" variant="primary" label="Смотреть урок" />
<IconButton name="bookmark" variant="glass" label="В избранное" />
```

`label` is required. Press state shrinks to 0.94 — no colour change.
