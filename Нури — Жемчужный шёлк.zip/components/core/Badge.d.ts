import * as React from "react";
/** Small status pill — counts, states, labels on imagery. */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: "accent" | "gold" | "neutral" | "dark" | "success" | "warning" | "danger";
  children?: React.ReactNode;
}
export declare function Badge(props: BadgeProps): JSX.Element;
