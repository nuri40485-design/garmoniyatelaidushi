import * as React from "react";
/** Round, pearl-shaped icon-only control. */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Lucide icon id */
  name: string;
  size?: "sm" | "md" | "lg";
  variant?: "primary" | "secondary" | "ghost" | "glass";
  /** Required accessible name */
  label: string;
  disabled?: boolean;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
