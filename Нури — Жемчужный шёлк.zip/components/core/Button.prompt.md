Primary action control — use `primary` once per view, `secondary` for the alternative, `ghost` for tertiary links-in-place, `dark` on pearl-light sections that need weight.

```jsx
<Button variant="primary" size="lg" iconLeft={<Icon name="sparkles" />}>Записаться на курс</Button>
<Button variant="secondary">Подробнее</Button>
```

Notes: radius is always a pill; never square a Button. `fullWidth` for mobile sheets. Hover lifts 1px and runs a left→right shimmer; press settles back with a 0.985 scale. Disabled drops to 45% opacity — never grey the fill out.
