import React from "react";

/** Lucide (static SVG, CDN) rendered as a currentColor mask so it inherits text colour. */
export function Icon({ name = "sparkles", size = 20, strokeWidth, style, ...rest }) {
  const url = `https://cdn.jsdelivr.net/npm/lucide-static@0.544.0/icons/${name}.svg`;
  return (
    <span
      {...rest}
      aria-hidden="true"
      style={{
        display: "inline-block",
        width: size,
        height: size,
        flex: "none",
        background: "currentColor",
        WebkitMaskImage: `url(${url})`,
        maskImage: `url(${url})`,
        WebkitMaskRepeat: "no-repeat",
        maskRepeat: "no-repeat",
        WebkitMaskSize: "contain",
        maskSize: "contain",
        opacity: strokeWidth === "light" ? 0.75 : 1,
        ...style,
      }}
    />
  );
}
