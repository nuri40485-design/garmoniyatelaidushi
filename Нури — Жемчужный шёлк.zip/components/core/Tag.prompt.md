Interactive chip for filtering lists of lessons and practices.

```jsx
<Tag selected>Лицо</Tag>
<Tag>Осанка</Tag>
<Tag onRemove={() => {}}>Дыхание</Tag>
```

Selected uses the satin accent gradient; unselected is pearl with a soft hairline. Lay chip rows out with flex + `gap: var(--gap-inline)`.
