The only icon primitive — wraps Lucide static SVGs as a currentColor mask, so an icon always matches the text beside it.

```jsx
<Icon name="moon-star" size={24} />
<Button iconLeft={<Icon name="heart" size={16} />}>Сохранить</Button>
```

Brand icon vocabulary: `heart`, `moon-star`, `sparkles`, `flower-2`, `hand-heart`, `activity`, `book-open`, `play`, `clock`, `check`. Never mix in filled or duotone icons, and never substitute emoji.
