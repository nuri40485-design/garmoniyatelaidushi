import * as React from "react";
/**
 * Content container. Pearl glass with a gold hairline is the default look.
 * @startingPoint section="Core" subtitle="Pearl-glass card in five finishes" viewport="700x260"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "pearl" | "solid" | "silk" | "dark" | "outline";
  padding?: "none" | "sm" | "md" | "lg";
  /** Adds pointer cursor and a 3px hover lift */
  interactive?: boolean;
  children?: React.ReactNode;
}
export declare function Card(props: CardProps): JSX.Element;
