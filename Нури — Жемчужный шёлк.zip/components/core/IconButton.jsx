import React from "react";
import { Icon } from "./Icon.jsx";

const S = { sm: 36, md: 46, lg: 56 };

export function IconButton({ name, size = "md", variant = "secondary", label, disabled = false, style, ...rest }) {
  const d = S[size] || S.md;
  const variants = {
    primary: { background: "var(--grad-accent)", color: "var(--text-on-accent)", boxShadow: "var(--shadow-accent)", border: "1px solid transparent" },
    secondary: { background: "var(--surface-raised)", color: "var(--aloewood-600)", boxShadow: "var(--shadow-sm)", border: "1px solid var(--line-gold)" },
    ghost: { background: "transparent", color: "var(--aloewood-600)", border: "1px solid transparent" },
    glass: { background: "var(--surface-glass)", color: "var(--text-strong)", border: "1px solid var(--line-hairline)", backdropFilter: "var(--blur-glass)" },
  };
  return (
    <button
      {...rest}
      aria-label={label}
      disabled={disabled}
      className={"nuri-iconbtn" + (rest.className ? " " + rest.className : "")}
      style={{ width: d, height: d, display: "inline-grid", placeItems: "center", borderRadius: "var(--radius-pearl)", cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.45 : 1, transition: "var(--t-all)", ...(variants[variant] || variants.secondary), ...style }}
    >
      <style>{`.nuri-iconbtn:hover:not(:disabled){transform:translateY(-1px)}.nuri-iconbtn:active:not(:disabled){transform:scale(.94)}.nuri-iconbtn:focus-visible{outline:none;box-shadow:var(--ring-focus)}`}</style>
      <Icon name={name} size={Math.round(d * 0.42)} />
    </button>
  );
}
