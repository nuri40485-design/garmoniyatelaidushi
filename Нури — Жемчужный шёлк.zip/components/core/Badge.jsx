import React from "react";

export function Badge({ tone = "accent", children, style, ...rest }) {
  const tones = {
    accent: { background: "var(--sakura-500)", color: "var(--text-on-accent)" },
    gold: { background: "var(--gold)", color: "#3A2A16" },
    neutral: { background: "var(--surface-sunken)", color: "var(--text-body)" },
    dark: { background: "var(--choco-800)", color: "var(--pearl-100)" },
    success: { background: "var(--success-bg)", color: "var(--success)" },
    warning: { background: "var(--warning-bg)", color: "var(--warning)" },
    danger: { background: "var(--danger-bg)", color: "var(--danger)" },
  };
  return (
    <span
      {...rest}
      style={{ display: "inline-flex", alignItems: "center", gap: "var(--sp-1)", height: 24, padding: "0 var(--sp-3)", borderRadius: "var(--radius-pill)", font: "var(--text-caption)", letterSpacing: ".03em", whiteSpace: "nowrap", ...(tones[tone] || tones.accent), ...style }}
    >
      {children}
    </span>
  );
}
