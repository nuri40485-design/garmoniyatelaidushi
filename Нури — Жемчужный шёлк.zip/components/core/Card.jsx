import React from "react";

export function Card({ variant = "pearl", padding = "md", interactive = false, children, style, ...rest }) {
  const variants = {
    pearl: { background: "var(--surface-card)", backdropFilter: "var(--blur-glass)", border: "1px solid var(--line-gold)", boxShadow: "var(--shadow-md), var(--inset-satin)" },
    solid: { background: "var(--surface-raised)", border: "var(--border-hairline)", boxShadow: "var(--shadow-sm)" },
    silk: { background: "var(--grad-silk)", border: "1px solid rgba(255,255,255,.6)", boxShadow: "var(--shadow-md), var(--inset-satin)" },
    dark: { background: "var(--grad-dark)", border: "1px solid rgba(201,168,118,.35)", color: "var(--text-on-dark)", boxShadow: "var(--shadow-lg)" },
    outline: { background: "transparent", border: "var(--border-gold)" },
  };
  const pads = { none: 0, sm: "var(--sp-4)", md: "var(--pad-card)", lg: "var(--pad-card-lg)" };
  return (
    <div
      {...rest}
      className={"nuri-card" + (interactive ? " is-interactive" : "") + (rest.className ? " " + rest.className : "")}
      style={{ borderRadius: "var(--radius-lg)", padding: pads[padding], transition: "var(--t-lift)", overflow: "hidden", ...(variants[variant] || variants.pearl), ...style }}
    >
      <style>{`.nuri-card.is-interactive{cursor:pointer}.nuri-card.is-interactive:hover{transform:translateY(-3px);box-shadow:var(--shadow-lg)}.nuri-card.is-interactive:active{transform:translateY(-1px)}`}</style>
      {children}
    </div>
  );
}
