import React from "react";

const SIZES = {
  sm: { h: "var(--control-h-sm)", px: "var(--sp-4)", fs: "var(--fs-xs)" },
  md: { h: "var(--control-h-md)", px: "var(--pad-control-x)", fs: "var(--fs-sm)" },
  lg: { h: "var(--control-h-lg)", px: "var(--sp-6)", fs: "var(--fs-md)" },
};

export function Button({
  variant = "primary",
  size = "md",
  disabled = false,
  fullWidth = false,
  iconLeft,
  iconRight,
  as = "button",
  children,
  style,
  ...rest
}) {
  const s = SIZES[size] || SIZES.md;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--gap-inline)",
    minHeight: s.h,
    padding: `0 ${s.px}`,
    width: fullWidth ? "100%" : undefined,
    font: `var(--fw-semibold) ${s.fs}/1 var(--font-body)`,
    letterSpacing: ".04em",
    borderRadius: "var(--radius-pill)",
    border: "1px solid transparent",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.45 : 1,
    position: "relative",
    overflow: "hidden",
    textDecoration: "none",
    transition: "var(--t-all)",
    WebkitTapHighlightColor: "transparent",
  };
  const variants = {
    primary: {
      background: "var(--grad-accent)",
      color: "var(--text-on-accent)",
      boxShadow: "var(--shadow-accent), var(--inset-letterpress)",
    },
    secondary: {
      background: "var(--surface-raised)",
      color: "var(--text-strong)",
      borderColor: "var(--line-gold)",
      boxShadow: "var(--shadow-sm)",
    },
    ghost: { background: "transparent", color: "var(--aloewood-600)" },
    dark: {
      background: "var(--grad-dark)",
      color: "var(--text-on-dark)",
      boxShadow: "var(--shadow-md), var(--inset-satin)",
    },
  };
  const Tag = as;
  return (
    <Tag
      {...rest}
      disabled={Tag === "button" ? disabled : undefined}
      className={"nuri-btn" + (rest.className ? " " + rest.className : "")}
      style={{ ...base, ...(variants[variant] || variants.primary), ...style }}
    >
      <style>{`.nuri-btn:hover:not(:disabled){transform:translateY(-1px);filter:saturate(1.05) brightness(1.02)}.nuri-btn:active:not(:disabled){transform:translateY(0) scale(.985)}.nuri-btn:focus-visible{outline:none;box-shadow:var(--ring-focus)}.nuri-btn>.nuri-shim{position:absolute;inset:0;pointer-events:none;background:var(--grad-shimmer);opacity:0;transform:translateX(-120%)}.nuri-btn:hover>.nuri-shim{opacity:1;animation:nuri-shimmer var(--dur-slow) var(--ease-silk)}`}</style>
      {iconLeft}
      <span style={{ position: "relative" }}>{children}</span>
      {iconRight}
      <span className="nuri-shim" />
    </Tag>
  );
}
