import React from "react";

export function Tag({ selected = false, onRemove, children, style, ...rest }) {
  return (
    <button
      {...rest}
      className={"nuri-tag" + (rest.className ? " " + rest.className : "")}
      aria-pressed={selected}
      style={{
        display: "inline-flex", alignItems: "center", gap: "var(--sp-2)", minHeight: 34,
        padding: "0 var(--sp-4)", borderRadius: "var(--radius-pill)",
        font: "var(--fw-medium) var(--fs-sm)/1 var(--font-body)", cursor: "pointer",
        transition: "var(--t-all)",
        background: selected ? "var(--grad-accent)" : "var(--surface-raised)",
        color: selected ? "var(--text-on-accent)" : "var(--text-body)",
        border: selected ? "1px solid transparent" : "1px solid var(--line-soft)",
        boxShadow: selected ? "var(--shadow-accent)" : "none",
        ...style,
      }}
    >
      <style>{`.nuri-tag:hover{border-color:var(--line-gold);color:var(--text-strong)}.nuri-tag[aria-pressed="true"]:hover{color:var(--text-on-accent)}.nuri-tag:active{transform:scale(.97)}.nuri-tag:focus-visible{outline:none;box-shadow:var(--ring-focus)}`}</style>
      {children}
      {onRemove && (
        <span onClick={(e) => { e.stopPropagation(); onRemove(e); }} style={{ opacity: 0.6, fontSize: 14, lineHeight: 1 }}>×</span>
      )}
    </button>
  );
}
