import * as React from "react";
/** Transient notification strip; rises in over 320ms. */
export interface ToastProps {
  tone?: "info" | "success" | "warning" | "danger";
  title?: string;
  message?: string;
  onClose?: () => void;
}
export declare function Toast(props: ToastProps): JSX.Element;
