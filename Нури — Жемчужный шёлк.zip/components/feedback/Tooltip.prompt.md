Short clarification on an icon-only control. Never put essential copy here.

```jsx
<Tooltip content="Дневник практик"><IconButton name="book-open" label="Дневник" /></Tooltip>
```
