import React from "react";

export function Tooltip({ content, placement = "top", children }) {
  const pos = {
    top: { bottom: "calc(100% + 8px)", left: "50%", transform: "translateX(-50%)" },
    bottom: { top: "calc(100% + 8px)", left: "50%", transform: "translateX(-50%)" },
    left: { right: "calc(100% + 8px)", top: "50%", transform: "translateY(-50%)" },
    right: { left: "calc(100% + 8px)", top: "50%", transform: "translateY(-50%)" },
  }[placement];
  return (
    <span className="nuri-tip" style={{ position: "relative", display: "inline-flex" }}>
      <style>{`.nuri-tip>.nuri-tip-b{opacity:0;pointer-events:none;transition:opacity var(--dur-quick) var(--ease-silk)}.nuri-tip:hover>.nuri-tip-b,.nuri-tip:focus-within>.nuri-tip-b{opacity:1}`}</style>
      {children}
      <span className="nuri-tip-b" style={{ position: "absolute", zIndex: 30, whiteSpace: "nowrap", padding: "6px var(--sp-3)", background: "var(--choco-800)", color: "var(--pearl-100)", borderRadius: "var(--radius-sm)", font: "var(--text-caption)", boxShadow: "var(--shadow-sm)", ...pos }}>{content}</span>
    </span>
  );
}
