import * as React from "react";
/** Centered modal over a chocolate veil with heavy blur. */
export interface DialogProps {
  open?: boolean;
  title?: string;
  children?: React.ReactNode;
  /** Action row, right-aligned — usually two Buttons */
  footer?: React.ReactNode;
  onClose?: () => void;
  /** max-width in px, default 480 */
  width?: number;
}
export declare function Dialog(props: DialogProps): JSX.Element | null;
