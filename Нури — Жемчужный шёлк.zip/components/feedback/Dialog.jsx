import React from "react";
import { IconButton } from "../core/IconButton.jsx";

export function Dialog({ open = true, title, children, footer, onClose, width = 480 }) {
  if (!open) return null;
  return (
    <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", padding: "var(--sp-5)", background: "rgba(46,31,23,.38)", backdropFilter: "var(--blur-veil)", zIndex: 40 }}>
      <div style={{ width: "100%", maxWidth: width, background: "var(--surface-raised)", border: "var(--border-gold)", borderRadius: "var(--radius-lg)", boxShadow: "var(--shadow-lg)", padding: "var(--pad-card-lg)", animation: "nuri-rise var(--dur-base) var(--ease-out-soft) both" }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "var(--sp-4)", marginBottom: "var(--sp-4)" }}>
          <h4 style={{ margin: 0 }}>{title}</h4>
          {onClose && <IconButton name="x" size="sm" variant="ghost" label="Закрыть" onClick={onClose} />}
        </div>
        <div style={{ font: "var(--text-body-sm)", color: "var(--text-body)" }}>{children}</div>
        {footer && <div style={{ display: "flex", justifyContent: "flex-end", gap: "var(--gap-inline)", marginTop: "var(--sp-6)" }}>{footer}</div>}
      </div>
    </div>
  );
}
