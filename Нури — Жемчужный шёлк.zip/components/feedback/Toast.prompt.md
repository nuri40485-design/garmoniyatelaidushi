Confirmation after a completed practice, a saved lesson, a failed payment.

```jsx
<Toast tone="success" title="Практика завершена" message="Отмечено в дневнике." onClose={dismiss} />
```

Stack toasts bottom-right on desktop, top on mobile, `gap: var(--sp-3)`.
