Modal for enrolment confirmation, practice reminders, verse of the day.

```jsx
<Dialog open={open} title="Начнём практику?" onClose={close}
  footer={<><Button variant="ghost" onClick={close}>Позже</Button><Button>Начать</Button></>}>
  <p>15 минут мягкого самомассажа шеи.</p>
</Dialog>
```

The overlay is positioned `absolute`, so give the containing screen `position: relative`.
