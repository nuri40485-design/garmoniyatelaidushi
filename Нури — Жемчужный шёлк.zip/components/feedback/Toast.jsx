import React from "react";
import { Icon } from "../core/Icon.jsx";

const TONES = {
  info: { icon: "sparkles", color: "var(--aloewood-600)", bg: "var(--surface-raised)" },
  success: { icon: "check", color: "var(--success)", bg: "var(--success-bg)" },
  warning: { icon: "clock", color: "var(--warning)", bg: "var(--warning-bg)" },
  danger: { icon: "triangle-alert", color: "var(--danger)", bg: "var(--danger-bg)" },
};

export function Toast({ tone = "info", title, message, onClose }) {
  const t = TONES[tone] || TONES.info;
  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: "var(--sp-3)", width: "100%", maxWidth: 380, padding: "var(--sp-4)", background: t.bg, border: "var(--border-gold)", borderRadius: "var(--radius-md)", boxShadow: "var(--shadow-md)", animation: "nuri-rise var(--dur-base) var(--ease-out-soft) both" }}>
      <span style={{ color: t.color, marginTop: 2 }}><Icon name={t.icon} size={18} /></span>
      <div style={{ flex: 1, minWidth: 0 }}>
        {title && <div style={{ font: "var(--fw-semibold) var(--fs-sm)/1.3 var(--font-body)", color: "var(--text-strong)" }}>{title}</div>}
        {message && <div style={{ font: "var(--text-body-sm)", color: "var(--text-muted)" }}>{message}</div>}
      </div>
      {onClose && <button onClick={onClose} aria-label="Закрыть" style={{ border: 0, background: "transparent", color: "var(--text-muted)", cursor: "pointer", fontSize: 16, lineHeight: 1 }}>×</button>}
    </div>
  );
}
