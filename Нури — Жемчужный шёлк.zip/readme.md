# Нури — «Жемчужный шёлк» / Nuri Design System

Design system for **Нури о женском** — a women's self-care practice brand: self-massage through biomechanics, neurogymnastics and women's gymnastics, taught through the lens of Islam, the Qur'an and the Sunnah. The audience is Muslim women; the register is warm, modest, unhurried, and physically concrete.

Image name: **«Жемчужный шёлк» (Pearl Silk)** — premium feminine aesthetics at the meeting point of Eastern luxury and soft naturalness.

## Sources given

- A written brand brief (palette, materials, typography, UI and motion direction) supplied in chat. This is the primary source of truth.
- Seven reference images, uploaded to `uploads/` and curated into `assets/`:
  - `b7abfb729b0ca872a0c9fbc3a67515e9.jpg` — palette card (Dark Chocolate / Aloewood / Milk Tea / Sakura / Misty Rose) → `assets/reference/palette-reference.jpg`
  - `OIP (2).webp` — rose satin waves → `assets/textures/silk-rose-wave.webp`
  - `OIP (3).webp` — rose-gold foil → `assets/textures/rose-gold-foil.webp`
  - `OIP (1).webp` — pearl in shell → `assets/imagery/pearl-in-shell.webp`
  - `photo_2026-09-11_13-53-29.jpg` — roses, pearls, gold jewellery on silk → `assets/imagery/roses-pearls-gold.jpg`
  - `photo_16_2026-09-09_14-33-03.jpg` — pearl shell on a beach (phone screenshot; cropped to the image area) → `assets/imagery/pearl-shell-beach.png`
  - `photo_6_2026-09-09_14-33-03.jpg` — gold "money tree" render; off-brief (wealth imagery, not women's wellbeing), **not adopted**.

No codebase, Figma file, slide deck or logo was provided. There is therefore **no logo mark** in this system: wherever a mark would go, set the name **Нури** in Playfair Display with the line «о женском» beneath it in uppercase eyebrow type (see `guidelines/brand-wordmark.card.html`). Do not draw or invent a mark.

Two corrections to the brief, applied deliberately:
- `Misty Rose #F2CF2A` is a yellow, while the reference swatch is pale pink. Implemented as **`#F7D9D9`**.
- The brief's Sakura → Rose Gold "gradient" is implemented as a three-stop satin ramp `Sakura → Rose Gold → Gold` (`--grad-accent`) so buttons read as metal-touched silk rather than flat pink.

## Index

| File | What it is |
|---|---|
| `styles.css` | The only entry point consumers link. `@import` list only. |
| `tokens/fonts.css` | Google Fonts import (Playfair Display, Manrope, Amiri) |
| `tokens/colors.css` | Base ramps, semantic aliases, all gradients |
| `tokens/typography.css` | Families, scale, composite `font:` shorthands |
| `tokens/spacing.css` | Space scale, containers, control heights, radii |
| `tokens/effects.css` | Shadows, satin/letterpress insets, glass, pearl bead |
| `tokens/motion.css` | Easings, durations, keyframes, reduced-motion guard |
| `tokens/base.css` | Element resets, link colours, `.nuri-*` utility classes |
| `guidelines/*.card.html` | 21 foundation specimen cards (Colors, Type, Spacing, Effects, Brand) |
| `components/core/` | Button, IconButton, Card, Badge, Tag, Icon |
| `components/forms/` | Input, Select, Checkbox, Radio, Switch |
| `components/feedback/` | Dialog, Toast, Tooltip |
| `components/navigation/` | Tabs |
| `components/brand/` | PearlBullet, SilkDivider, AyahQuote |
| `ui_kits/website/` | Marketing site recreation (`index.html`, `Site.jsx`) |
| `ui_kits/app/` | Practice app recreation (`index.html`, `App.jsx`) |
| `assets/` | Textures, imagery, palette reference |
| `SKILL.md` | Agent-skill entry point |

**Intentional additions.** No source defined a component inventory, so the standard set was authored. Three brand-specific primitives were added because the brief names them as required motifs: `PearlBullet` (the pearl bead motif), `SilkDivider` (wave / gold hairline / pearl-row section breaks, since the brief forbids straight rules) and `AyahQuote` (Qur'anic verse block — the brand's defining content type).

---

## CONTENT FUNDAMENTALS

**Language.** Russian, with Arabic reserved for Qur'anic text and a small set of Islamic expressions (`ин ша Аллах`, `Ассаляму алейкум`, `Альхамдулиллях`). Arabic script appears only inside `AyahQuote` — never as decoration.

**Person.** Address the reader as **вы** (lowercase, non-capitalised «вы» in body copy), the author speaks as **я** or **мы** when it's the school. Never «ты». Everything is grammatically feminine: *записалась*, *почувствовала*, *участница*, *наставница*.

**Tone.** Calm, instructive, physically specific. Describe the body, not the outcome: «ладони на нижние рёбра, вдох в стороны» rather than «почувствуйте энергию». No urgency, no scarcity, no shouting. Nothing is «трансформация», «прокачка» or «женская энергия» — the brand is biomechanics plus faith, not esoterics.

**Casing.** Sentence case everywhere. Uppercase only in eyebrows and metadata labels (`КУРС · 12 УРОКОВ`), where tracking is `0.16em`. Never uppercase a headline or a button label — buttons are sentence case: «Записаться на курс», «Пробный урок», «Начать».

**Length.** Headlines 2–5 words («Мягкая сила женского тела»). Lead paragraphs one or two sentences. Card descriptions under 60 characters. Practice steps as three short imperatives.

**Numbers.** Russian spacing and units: `1 900 ₽`, `12 мин`, `2 / 48 уроков`, dates `09.2027`.

**Emoji: never.** Not in copy, not in UI, not in social captions rendered inside the product. The pearl bead (`PearlBullet`) is the brand's only ornamental marker.

**Examples.**
- Hero: «Мягкая сила женского тела» / «Самомассаж через биомеханику, нейрогимнастика и женская гимнастика. Двадцать минут в день — для тела, дыхания и спокойствия.»
- Confirmation: «Заявка отправлена. Напишем в течение дня, ин ша Аллах.»
- Practice card: «Вечерний ритуал — расслабление перед сном и намазом.»
- Setting label: «Тихий режим в намаз».

---

## VISUAL FOUNDATIONS

**Colour.** Two ramps and one metal. Browns (`#2E1F17 → #DCC3B2`) carry all text and all depth; roses (`#D97E80 → #FFF8F3`) carry accent and air; gold (`#E8B4B8 → #A98A57`) appears only as hairlines, 1px borders and small marks — never as a fill larger than an icon. Body text is warm brown (`--text-body: #5C4230`), never black. Maximum two background colours per page: Pearl White `#FFF8F3` and one rose ground (Misty Rose or a silk gradient). Semantics are desaturated and warm-shifted; no system red/green.

**Type.** Playfair Display for every heading (high-stroke-contrast serif, regular weight at display sizes, medium at 24–44px, tight `-0.015em`). Manrope for body, labels and UI, 1.62 line height, light 300 for leads and regular 400 for text. Amiri for Arabic only. Two families total — no third face. Headlines get real air: at least `--sp-5` below an eyebrow and `--sp-6` before the next block.

**Spacing & layout.** 4px base, but the rhythm is generous: cards pad at 24–32px, sections at 96px (`--gap-section`). Reading measure caps at 760px (`--container-md`); full layouts at 1080–1280px. Controls are 36 / 46 / 56px tall, taps never below 44px. The site header is the only fixed element (sticky, glass); the app's tab bar is pinned to the bottom of the device frame.

**Backgrounds.** Never flat where a section wants presence. Three treatments: (1) Pearl White plain, for text-dense sections; (2) a diagonal silk gradient (`--grad-silk`, 3–4 rose stops at 135°), optionally with `silk-rose-wave.webp` overlaid at 45% in `soft-light`; (3) chocolate silk (`--grad-dark`) for footers and verse bands. Full-bleed photography is used once per page at most, always with `--grad-veil` under any text on it.

**Imagery.** Warm, soft-focus, close-up: pearls, roses, satin, gold filigree, skin and hands. Everything reads pink-gold and slightly overexposed. No cool tones, no grey, no black-and-white, no grain, no clinical fitness stock, and no faces are needed — texture carries the brand. Corner radius on imagery is `--radius-xl` (34px) when framed, none when full-bleed.

**Cards.** Default is pearl glass: `rgba(255,248,243,.72)` fill, `blur(14px) saturate(1.08)`, a 1px `rgba(201,168,118,.55)` gold hairline, `--shadow-md` outside and `--inset-satin` inside, radius 24px. `solid` (opaque pearl, hairline border, `--shadow-sm`) inside app screens, where glass over glass muddies. `silk` for exactly one highlighted card per view. `dark` for verses and testimonials.

**Borders.** Hairlines only — 1px, warm, and mostly translucent: `rgba(170,127,102,.24)` for dividers, gold at 55% for card edges. No 2px borders, no left-border accent stripes.

**Shadows.** Outer shadows are always brown-rose tinted, never neutral: `0 4px 12px rgba(170,127,102,.16)` up to `0 20px 48px rgba(68,48,37,.16)`; accent buttons add `0 10px 24px rgba(236,156,157,.38)`. Inner light is the signature: `--inset-satin` (white top edge, brown bottom edge) on raised satin surfaces, `--inset-letterpress` on accent buttons for the pressed-foil feel, `--inset-well` on inputs so they read as recessed.

**Radii.** Nothing sharp: 6px minimum (checkbox), 10 / 16 / 24 / 34px for surfaces, pill for every button, tag, input and progress track, and full circle for icon buttons, pearls and avatars.

**Transparency & blur.** Blur is used in exactly three places: glass cards over imagery, sticky/bottom navigation bars, and the modal veil (`rgba(46,31,23,.38)` + `blur(28px)`). Never blur behind body text on a plain background.

**Motion.** One easing — `--ease-silk` `cubic-bezier(.22,.61,.36,1)`. Durations 180ms (colour), 320ms (default), 480ms (shimmer), 600ms (block reveal). Blocks enter with `nuri-rise`: fade plus 18px up plus 0.985 → 1 scale. Decoration: two or three pearls drifting on a 6s `nuri-float`, at 30–50% opacity. Buttons run a left-to-right shimmer on hover (`nuri-shimmer`, 480ms). No bounce, no spin, no parallax, nothing under 150ms. `prefers-reduced-motion` disables all of it.

**Hover.** Lift, don't darken: `translateY(-1px)` plus a slight `saturate(1.05) brightness(1.02)` on filled buttons; cards lift 3px to `--shadow-lg`; ghost and nav items shift from `--text-muted` to `--text-strong`; links go from Aloewood to Sakura.

**Press.** Scale down, hold colour: buttons `scale(.985)` back to `translateY(0)`, icon buttons `scale(.94)`, tags `scale(.97)`. No press-darkening.

**Focus.** A 3px `rgba(236,156,157,.55)` ring, replacing the outline. Inputs additionally switch their border to Sakura.

**Disabled.** 45% opacity on the whole control, fill preserved — never a grey fill.

**Section breaks.** Silk waves (`SilkDivider variant="wave"`, 64px, the next section's colour bleeding upward), a gold hairline gradient that fades at both ends, or a pearl row. Straight full-width rules are off-brand.

---

## ICONOGRAPHY

No icon assets were supplied. **Substitution flagged:** the system uses **Lucide** (static SVG, `lucide-static@0.544.0` via jsDelivr) — a 24×24, 2px-stroke, round-cap outline set, the closest open match to the brief's «тонкие золотые контуры» direction. Swap it for the brand's own set when one exists; only `components/core/Icon.jsx` needs to change.

- Icons are always rendered through the `Icon` component, which masks the SVG with `background: currentColor`, so an icon inherits the colour of the text next to it. Never colour an icon independently of its label.
- Sizes: 16px inside buttons and list rows, 20px in navigation, 24px as a card marker. Stroke weight is uniform; there are no filled, duotone or multicolour icons.
- Brand vocabulary: `heart`, `moon-star`, `sparkles`, `flower-2`, `hand-heart`, `activity`, `book-open`, `play`, `pause`, `clock`, `check`, `bookmark`, `chevron-right`.
- **Emoji are never used** as icons or in copy. Unicode symbols are used only for the ruble sign `₽`, the multiplication sign `×` as a close affordance, and `·` as a metadata separator.
- Decorative "icon" duties belong to the pearl bead (`PearlBullet`) and the gold hairline, not to the icon set.

## Fonts — action needed

All three families load from the Google Fonts CDN because no licensed binaries were provided. Playfair Display and Manrope both carry Cyrillic; Amiri carries Arabic. **If the brand owns different faces (or licensed webfont files), send them and `tokens/fonts.css` will be rewritten as `@font-face` rules against local binaries.**
