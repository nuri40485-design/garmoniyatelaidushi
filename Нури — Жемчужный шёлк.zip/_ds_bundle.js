/* @ds-bundle: {"format":4,"namespace":"Ds_aa95d3","components":[{"name":"AyahQuote","sourcePath":"components/brand/AyahQuote.jsx"},{"name":"PearlBullet","sourcePath":"components/brand/PearlBullet.jsx"},{"name":"SilkDivider","sourcePath":"components/brand/SilkDivider.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/brand/AyahQuote.jsx":"2ac4aebd5c0b","components/brand/PearlBullet.jsx":"de33cdfae9a1","components/brand/SilkDivider.jsx":"97bce926d31d","components/core/Badge.jsx":"a40a184b2caa","components/core/Button.jsx":"f47e0711f35a","components/core/Card.jsx":"f985443f172c","components/core/Icon.jsx":"b994a4485d9a","components/core/IconButton.jsx":"836a01e1ea1e","components/core/Tag.jsx":"3779943ff32b","components/feedback/Dialog.jsx":"22737ac82a80","components/feedback/Toast.jsx":"0b7023b9d213","components/feedback/Tooltip.jsx":"9bb6711f5e51","components/forms/Checkbox.jsx":"81b02a5917c0","components/forms/Input.jsx":"1a5d5a3e9aeb","components/forms/Radio.jsx":"23c48d35a4e2","components/forms/Select.jsx":"f8801a32f106","components/forms/Switch.jsx":"8fb5e974220c","components/navigation/Tabs.jsx":"c25f1727d301","ui_kits/app/App.jsx":"66a2914eb647","ui_kits/website/Site.jsx":"261c7ad40e4c"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.Ds_aa95d3 = window.Ds_aa95d3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/AyahQuote.jsx
try { (() => {
function AyahQuote({
  arabic,
  translation,
  source,
  tone = "light"
}) {
  const dark = tone === "dark";
  return /*#__PURE__*/React.createElement("figure", {
    style: {
      margin: 0,
      padding: "var(--pad-card-lg)",
      borderRadius: "var(--radius-lg)",
      background: dark ? "var(--grad-dark)" : "var(--surface-card)",
      backdropFilter: dark ? undefined : "var(--blur-glass)",
      border: dark ? "1px solid rgba(201,168,118,.35)" : "var(--border-gold)",
      boxShadow: "var(--shadow-md)",
      textAlign: "center"
    }
  }, arabic && /*#__PURE__*/React.createElement("p", {
    className: "nuri-arabic",
    style: {
      margin: "0 0 var(--sp-4)",
      color: dark ? "var(--pearl-100)" : "var(--text-strong)"
    }
  }, arabic), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "var(--sp-3)",
      margin: "0 0 var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 1,
      background: "var(--grad-gold-line)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: "var(--radius-pearl)",
      background: "var(--grad-pearl)",
      boxShadow: "var(--pearl-shadow)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 1,
      background: "var(--grad-gold-line)"
    }
  })), translation && /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      font: "var(--fw-regular) var(--fs-d4)/1.45 var(--font-display)",
      fontStyle: "italic",
      color: dark ? "var(--pearl-100)" : "var(--text-strong)"
    }
  }, translation), source && /*#__PURE__*/React.createElement("figcaption", {
    style: {
      marginTop: "var(--sp-4)",
      font: "var(--text-caption)",
      letterSpacing: "var(--ls-caps)",
      textTransform: "uppercase",
      color: dark ? "var(--gold-soft)" : "var(--aloewood-600)"
    }
  }, source));
}
Object.assign(__ds_scope, { AyahQuote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/AyahQuote.jsx", error: String((e && e.message) || e) }); }

// components/brand/PearlBullet.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function PearlBullet({
  size = 14,
  floating = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    "aria-hidden": "true",
    style: {
      width: size,
      height: size,
      flex: "none",
      display: "inline-block",
      borderRadius: "var(--radius-pearl)",
      background: "var(--grad-pearl)",
      boxShadow: "var(--pearl-shadow)",
      animation: floating ? "nuri-float 6s var(--ease-in-out-soft) infinite" : undefined,
      ...style
    }
  }));
}
Object.assign(__ds_scope, { PearlBullet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/PearlBullet.jsx", error: String((e && e.message) || e) }); }

// components/brand/SilkDivider.jsx
try { (() => {
function SilkDivider({
  variant = "wave",
  flip = false,
  height = 64,
  color = "var(--surface-page)"
}) {
  if (variant === "gold") {
    return /*#__PURE__*/React.createElement("hr", {
      style: {
        height: 1,
        border: 0,
        margin: 0,
        background: "var(--grad-gold-line)"
      }
    });
  }
  if (variant === "pearlRow") {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "var(--sp-3)",
        padding: "var(--sp-5) 0"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: "var(--grad-gold-line)"
      }
    }), [10, 14, 10].map((d, i) => /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        width: d,
        height: d,
        borderRadius: "var(--radius-pearl)",
        background: "var(--grad-pearl)",
        boxShadow: "var(--pearl-shadow)"
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: "var(--grad-gold-line)"
      }
    }));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height,
      overflow: "hidden",
      lineHeight: 0,
      transform: flip ? "rotate(180deg)" : undefined
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 1440 64",
    preserveAspectRatio: "none",
    style: {
      width: "100%",
      height: "100%",
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M0 40 C 240 -10 480 70 720 34 C 960 0 1200 62 1440 24 L1440 64 L0 64 Z",
    fill: color
  })));
}
Object.assign(__ds_scope, { SilkDivider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/SilkDivider.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Badge({
  tone = "accent",
  children,
  style,
  ...rest
}) {
  const tones = {
    accent: {
      background: "var(--sakura-500)",
      color: "var(--text-on-accent)"
    },
    gold: {
      background: "var(--gold)",
      color: "#3A2A16"
    },
    neutral: {
      background: "var(--surface-sunken)",
      color: "var(--text-body)"
    },
    dark: {
      background: "var(--choco-800)",
      color: "var(--pearl-100)"
    },
    success: {
      background: "var(--success-bg)",
      color: "var(--success)"
    },
    warning: {
      background: "var(--warning-bg)",
      color: "var(--warning)"
    },
    danger: {
      background: "var(--danger-bg)",
      color: "var(--danger)"
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-1)",
      height: 24,
      padding: "0 var(--sp-3)",
      borderRadius: "var(--radius-pill)",
      font: "var(--text-caption)",
      letterSpacing: ".03em",
      whiteSpace: "nowrap",
      ...(tones[tone] || tones.accent),
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    h: "var(--control-h-sm)",
    px: "var(--sp-4)",
    fs: "var(--fs-xs)"
  },
  md: {
    h: "var(--control-h-md)",
    px: "var(--pad-control-x)",
    fs: "var(--fs-sm)"
  },
  lg: {
    h: "var(--control-h-lg)",
    px: "var(--sp-6)",
    fs: "var(--fs-md)"
  }
};
function Button({
  variant = "primary",
  size = "md",
  disabled = false,
  fullWidth = false,
  iconLeft,
  iconRight,
  as = "button",
  children,
  style,
  ...rest
}) {
  const s = SIZES[size] || SIZES.md;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--gap-inline)",
    minHeight: s.h,
    padding: `0 ${s.px}`,
    width: fullWidth ? "100%" : undefined,
    font: `var(--fw-semibold) ${s.fs}/1 var(--font-body)`,
    letterSpacing: ".04em",
    borderRadius: "var(--radius-pill)",
    border: "1px solid transparent",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.45 : 1,
    position: "relative",
    overflow: "hidden",
    textDecoration: "none",
    transition: "var(--t-all)",
    WebkitTapHighlightColor: "transparent"
  };
  const variants = {
    primary: {
      background: "var(--grad-accent)",
      color: "var(--text-on-accent)",
      boxShadow: "var(--shadow-accent), var(--inset-letterpress)"
    },
    secondary: {
      background: "var(--surface-raised)",
      color: "var(--text-strong)",
      borderColor: "var(--line-gold)",
      boxShadow: "var(--shadow-sm)"
    },
    ghost: {
      background: "transparent",
      color: "var(--aloewood-600)"
    },
    dark: {
      background: "var(--grad-dark)",
      color: "var(--text-on-dark)",
      boxShadow: "var(--shadow-md), var(--inset-satin)"
    }
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({}, rest, {
    disabled: Tag === "button" ? disabled : undefined,
    className: "nuri-btn" + (rest.className ? " " + rest.className : ""),
    style: {
      ...base,
      ...(variants[variant] || variants.primary),
      ...style
    }
  }), /*#__PURE__*/React.createElement("style", null, `.nuri-btn:hover:not(:disabled){transform:translateY(-1px);filter:saturate(1.05) brightness(1.02)}.nuri-btn:active:not(:disabled){transform:translateY(0) scale(.985)}.nuri-btn:focus-visible{outline:none;box-shadow:var(--ring-focus)}.nuri-btn>.nuri-shim{position:absolute;inset:0;pointer-events:none;background:var(--grad-shimmer);opacity:0;transform:translateX(-120%)}.nuri-btn:hover>.nuri-shim{opacity:1;animation:nuri-shimmer var(--dur-slow) var(--ease-silk)}`), iconLeft, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative"
    }
  }, children), iconRight, /*#__PURE__*/React.createElement("span", {
    className: "nuri-shim"
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  variant = "pearl",
  padding = "md",
  interactive = false,
  children,
  style,
  ...rest
}) {
  const variants = {
    pearl: {
      background: "var(--surface-card)",
      backdropFilter: "var(--blur-glass)",
      border: "1px solid var(--line-gold)",
      boxShadow: "var(--shadow-md), var(--inset-satin)"
    },
    solid: {
      background: "var(--surface-raised)",
      border: "var(--border-hairline)",
      boxShadow: "var(--shadow-sm)"
    },
    silk: {
      background: "var(--grad-silk)",
      border: "1px solid rgba(255,255,255,.6)",
      boxShadow: "var(--shadow-md), var(--inset-satin)"
    },
    dark: {
      background: "var(--grad-dark)",
      border: "1px solid rgba(201,168,118,.35)",
      color: "var(--text-on-dark)",
      boxShadow: "var(--shadow-lg)"
    },
    outline: {
      background: "transparent",
      border: "var(--border-gold)"
    }
  };
  const pads = {
    none: 0,
    sm: "var(--sp-4)",
    md: "var(--pad-card)",
    lg: "var(--pad-card-lg)"
  };
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    className: "nuri-card" + (interactive ? " is-interactive" : "") + (rest.className ? " " + rest.className : ""),
    style: {
      borderRadius: "var(--radius-lg)",
      padding: pads[padding],
      transition: "var(--t-lift)",
      overflow: "hidden",
      ...(variants[variant] || variants.pearl),
      ...style
    }
  }), /*#__PURE__*/React.createElement("style", null, `.nuri-card.is-interactive{cursor:pointer}.nuri-card.is-interactive:hover{transform:translateY(-3px);box-shadow:var(--shadow-lg)}.nuri-card.is-interactive:active{transform:translateY(-1px)}`), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Lucide (static SVG, CDN) rendered as a currentColor mask so it inherits text colour. */
function Icon({
  name = "sparkles",
  size = 20,
  strokeWidth,
  style,
  ...rest
}) {
  const url = `https://cdn.jsdelivr.net/npm/lucide-static@0.544.0/icons/${name}.svg`;
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    "aria-hidden": "true",
    style: {
      display: "inline-block",
      width: size,
      height: size,
      flex: "none",
      background: "currentColor",
      WebkitMaskImage: `url(${url})`,
      maskImage: `url(${url})`,
      WebkitMaskRepeat: "no-repeat",
      maskRepeat: "no-repeat",
      WebkitMaskSize: "contain",
      maskSize: "contain",
      opacity: strokeWidth === "light" ? 0.75 : 1,
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const S = {
  sm: 36,
  md: 46,
  lg: 56
};
function IconButton({
  name,
  size = "md",
  variant = "secondary",
  label,
  disabled = false,
  style,
  ...rest
}) {
  const d = S[size] || S.md;
  const variants = {
    primary: {
      background: "var(--grad-accent)",
      color: "var(--text-on-accent)",
      boxShadow: "var(--shadow-accent)",
      border: "1px solid transparent"
    },
    secondary: {
      background: "var(--surface-raised)",
      color: "var(--aloewood-600)",
      boxShadow: "var(--shadow-sm)",
      border: "1px solid var(--line-gold)"
    },
    ghost: {
      background: "transparent",
      color: "var(--aloewood-600)",
      border: "1px solid transparent"
    },
    glass: {
      background: "var(--surface-glass)",
      color: "var(--text-strong)",
      border: "1px solid var(--line-hairline)",
      backdropFilter: "var(--blur-glass)"
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({}, rest, {
    "aria-label": label,
    disabled: disabled,
    className: "nuri-iconbtn" + (rest.className ? " " + rest.className : ""),
    style: {
      width: d,
      height: d,
      display: "inline-grid",
      placeItems: "center",
      borderRadius: "var(--radius-pearl)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "var(--t-all)",
      ...(variants[variant] || variants.secondary),
      ...style
    }
  }), /*#__PURE__*/React.createElement("style", null, `.nuri-iconbtn:hover:not(:disabled){transform:translateY(-1px)}.nuri-iconbtn:active:not(:disabled){transform:scale(.94)}.nuri-iconbtn:focus-visible{outline:none;box-shadow:var(--ring-focus)}`), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: name,
    size: Math.round(d * 0.42)
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  selected = false,
  onRemove,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({}, rest, {
    className: "nuri-tag" + (rest.className ? " " + rest.className : ""),
    "aria-pressed": selected,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-2)",
      minHeight: 34,
      padding: "0 var(--sp-4)",
      borderRadius: "var(--radius-pill)",
      font: "var(--fw-medium) var(--fs-sm)/1 var(--font-body)",
      cursor: "pointer",
      transition: "var(--t-all)",
      background: selected ? "var(--grad-accent)" : "var(--surface-raised)",
      color: selected ? "var(--text-on-accent)" : "var(--text-body)",
      border: selected ? "1px solid transparent" : "1px solid var(--line-soft)",
      boxShadow: selected ? "var(--shadow-accent)" : "none",
      ...style
    }
  }), /*#__PURE__*/React.createElement("style", null, `.nuri-tag:hover{border-color:var(--line-gold);color:var(--text-strong)}.nuri-tag[aria-pressed="true"]:hover{color:var(--text-on-accent)}.nuri-tag:active{transform:scale(.97)}.nuri-tag:focus-visible{outline:none;box-shadow:var(--ring-focus)}`), children, onRemove && /*#__PURE__*/React.createElement("span", {
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    style: {
      opacity: 0.6,
      fontSize: 14,
      lineHeight: 1
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open = true,
  title,
  children,
  footer,
  onClose,
  width = 480
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "grid",
      placeItems: "center",
      padding: "var(--sp-5)",
      background: "rgba(46,31,23,.38)",
      backdropFilter: "var(--blur-veil)",
      zIndex: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      maxWidth: width,
      background: "var(--surface-raised)",
      border: "var(--border-gold)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-lg)",
      padding: "var(--pad-card-lg)",
      animation: "nuri-rise var(--dur-base) var(--ease-out-soft) both"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: "var(--sp-4)",
      marginBottom: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: 0
    }
  }, title), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    name: "x",
    size: "sm",
    variant: "ghost",
    label: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-body-sm)",
      color: "var(--text-body)"
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: "var(--gap-inline)",
      marginTop: "var(--sp-6)"
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const TONES = {
  info: {
    icon: "sparkles",
    color: "var(--aloewood-600)",
    bg: "var(--surface-raised)"
  },
  success: {
    icon: "check",
    color: "var(--success)",
    bg: "var(--success-bg)"
  },
  warning: {
    icon: "clock",
    color: "var(--warning)",
    bg: "var(--warning-bg)"
  },
  danger: {
    icon: "triangle-alert",
    color: "var(--danger)",
    bg: "var(--danger-bg)"
  }
};
function Toast({
  tone = "info",
  title,
  message,
  onClose
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: "var(--sp-3)",
      width: "100%",
      maxWidth: 380,
      padding: "var(--sp-4)",
      background: t.bg,
      border: "var(--border-gold)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-md)",
      animation: "nuri-rise var(--dur-base) var(--ease-out-soft) both"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: t.color,
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--fw-semibold) var(--fs-sm)/1.3 var(--font-body)",
      color: "var(--text-strong)"
    }
  }, title), message && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-body-sm)",
      color: "var(--text-muted)"
    }
  }, message)), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "\u0417\u0430\u043A\u0440\u044B\u0442\u044C",
    style: {
      border: 0,
      background: "transparent",
      color: "var(--text-muted)",
      cursor: "pointer",
      fontSize: 16,
      lineHeight: 1
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  content,
  placement = "top",
  children
}) {
  const pos = {
    top: {
      bottom: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    bottom: {
      top: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    left: {
      right: "calc(100% + 8px)",
      top: "50%",
      transform: "translateY(-50%)"
    },
    right: {
      left: "calc(100% + 8px)",
      top: "50%",
      transform: "translateY(-50%)"
    }
  }[placement];
  return /*#__PURE__*/React.createElement("span", {
    className: "nuri-tip",
    style: {
      position: "relative",
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("style", null, `.nuri-tip>.nuri-tip-b{opacity:0;pointer-events:none;transition:opacity var(--dur-quick) var(--ease-silk)}.nuri-tip:hover>.nuri-tip-b,.nuri-tip:focus-within>.nuri-tip-b{opacity:1}`), children, /*#__PURE__*/React.createElement("span", {
    className: "nuri-tip-b",
    style: {
      position: "absolute",
      zIndex: 30,
      whiteSpace: "nowrap",
      padding: "6px var(--sp-3)",
      background: "var(--choco-800)",
      color: "var(--pearl-100)",
      borderRadius: "var(--radius-sm)",
      font: "var(--text-caption)",
      boxShadow: "var(--shadow-sm)",
      ...pos
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  checked,
  onChange,
  disabled = false,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-3)",
      minHeight: "var(--tap-min)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      flex: "none",
      display: "grid",
      placeItems: "center",
      borderRadius: "var(--radius-xs)",
      background: checked ? "var(--grad-accent)" : "var(--surface-raised)",
      border: checked ? "1px solid transparent" : "1px solid var(--line-soft)",
      boxShadow: checked ? "var(--shadow-xs)" : "var(--inset-well)",
      transition: "var(--t-all)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 6,
      borderLeft: "2px solid var(--text-on-accent)",
      borderBottom: "2px solid var(--text-on-accent)",
      transform: "rotate(-45deg) translate(0,-1px)",
      opacity: checked ? 1 : 0,
      transition: "opacity var(--dur-quick) var(--ease-silk)"
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-body-sm)",
      color: "var(--text-body)"
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  size = "md",
  prefix,
  suffix,
  multiline = false,
  style,
  ...rest
}) {
  const h = size === "sm" ? "var(--control-h-sm)" : size === "lg" ? "var(--control-h-lg)" : "var(--control-h-md)";
  const Field = multiline ? "textarea" : "input";
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-2)",
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-caption)",
      color: "var(--text-muted)",
      letterSpacing: ".04em"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "nuri-field",
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-3)",
      minHeight: multiline ? undefined : h,
      padding: multiline ? "var(--sp-3) var(--sp-4)" : "0 var(--sp-4)",
      background: "var(--surface-raised)",
      borderRadius: multiline ? "var(--radius-md)" : "var(--radius-pill)",
      border: error ? "1px solid var(--danger)" : "1px solid var(--line-soft)",
      boxShadow: "var(--inset-well)",
      transition: "var(--t-all)"
    }
  }, /*#__PURE__*/React.createElement("style", null, `.nuri-field:focus-within{border-color:var(--sakura-500);box-shadow:var(--ring-focus)}.nuri-field input,.nuri-field textarea{flex:1;min-width:0;border:0;outline:0;background:transparent;font:var(--text-body-sm);color:var(--text-strong);resize:vertical}.nuri-field input::placeholder,.nuri-field textarea::placeholder{color:var(--milktea-300)}`), prefix, /*#__PURE__*/React.createElement(Field, _extends({
    rows: multiline ? 4 : undefined,
    style: style
  }, rest)), suffix), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-caption)",
      fontWeight: "var(--fw-regular)",
      color: error ? "var(--danger)" : "var(--text-muted)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  label,
  checked,
  onChange,
  name,
  value,
  disabled = false,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-3)",
      minHeight: "var(--tap-min)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      flex: "none",
      display: "grid",
      placeItems: "center",
      borderRadius: "var(--radius-pearl)",
      background: checked ? "var(--grad-pearl)" : "var(--surface-raised)",
      border: checked ? "1px solid var(--line-gold)" : "1px solid var(--line-soft)",
      boxShadow: checked ? "var(--pearl-shadow)" : "var(--inset-well)",
      transition: "var(--t-all)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: "var(--radius-pearl)",
      background: "var(--sakura-600)",
      opacity: checked ? 1 : 0,
      transition: "opacity var(--dur-quick) var(--ease-silk)"
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-body-sm)",
      color: "var(--text-body)"
    }
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  hint,
  options = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-2)",
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-caption)",
      color: "var(--text-muted)",
      letterSpacing: ".04em"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "nuri-select",
    style: {
      position: "relative",
      display: "block"
    }
  }, /*#__PURE__*/React.createElement("style", null, `.nuri-select select{appearance:none;width:100%;min-height:var(--control-h-md);padding:0 var(--sp-7) 0 var(--sp-4);background:var(--surface-raised);border:1px solid var(--line-soft);border-radius:var(--radius-pill);box-shadow:var(--inset-well);font:var(--text-body-sm);color:var(--text-strong);cursor:pointer;transition:var(--t-all)}.nuri-select select:focus{outline:none;border-color:var(--sakura-500);box-shadow:var(--ring-focus)}.nuri-select .nuri-caret{position:absolute;right:var(--sp-5);top:50%;width:8px;height:8px;margin-top:-6px;border-right:1.5px solid var(--aloewood-600);border-bottom:1.5px solid var(--aloewood-600);transform:rotate(45deg);pointer-events:none}`), /*#__PURE__*/React.createElement("select", _extends({
    style: style
  }, rest), options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("span", {
    className: "nuri-caret"
  })), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-caption)",
      fontWeight: "var(--fw-regular)",
      color: "var(--text-muted)"
    }
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  label,
  checked = false,
  onChange,
  disabled = false,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--sp-4)",
      minHeight: "var(--tap-min)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 52,
      height: 30,
      flex: "none",
      padding: 3,
      borderRadius: "var(--radius-pill)",
      background: checked ? "var(--grad-accent)" : "var(--surface-sunken)",
      boxShadow: checked ? "var(--shadow-xs)" : "var(--inset-well)",
      transition: "var(--t-all)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      width: 24,
      height: 24,
      borderRadius: "var(--radius-pearl)",
      background: "var(--grad-pearl)",
      boxShadow: "var(--pearl-shadow)",
      transform: checked ? "translateX(22px)" : "none",
      transition: "transform var(--dur-base) var(--ease-silk)"
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-body-sm)",
      color: "var(--text-body)"
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  variant = "underline"
}) {
  const active = value ?? items[0]?.value;
  const isPill = variant === "pill";
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: "flex",
      gap: isPill ? "var(--sp-1)" : "var(--sp-6)",
      alignItems: "center",
      padding: isPill ? "var(--sp-1)" : 0,
      background: isPill ? "var(--surface-sunken)" : "transparent",
      borderRadius: isPill ? "var(--radius-pill)" : 0,
      borderBottom: isPill ? "none" : "1px solid var(--line-hairline)",
      overflowX: "auto"
    }
  }, items.map(it => {
    const on = it.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      role: "tab",
      "aria-selected": on,
      onClick: () => onChange && onChange(it.value),
      style: {
        border: 0,
        cursor: "pointer",
        whiteSpace: "nowrap",
        transition: "var(--t-all)",
        font: `${on ? "var(--fw-semibold)" : "var(--fw-medium)"} var(--fs-sm)/1 var(--font-body)`,
        color: on ? isPill ? "var(--text-on-accent)" : "var(--text-strong)" : "var(--text-muted)",
        padding: isPill ? "0 var(--sp-5)" : "0 0 var(--sp-3)",
        minHeight: isPill ? 38 : 34,
        background: isPill && on ? "var(--grad-accent)" : "transparent",
        borderRadius: isPill ? "var(--radius-pill)" : 0,
        boxShadow: isPill && on ? "var(--shadow-xs)" : "none",
        borderBottom: isPill ? "none" : `2px solid ${on ? "var(--sakura-500)" : "transparent"}`,
        marginBottom: isPill ? 0 : -1
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/App.jsx
try { (() => {
const {
  Button,
  IconButton,
  Card,
  Badge,
  Tag,
  Icon,
  PearlBullet,
  SilkDivider,
  AyahQuote,
  Tabs,
  Switch,
  Toast,
  Tooltip
} = window.Ds_aa95d3;
const LESSONS = [{
  id: 1,
  t: "Шея и плечи",
  d: "Мягкий самомассаж, 12 мин",
  tag: "Лицо",
  done: true
}, {
  id: 2,
  t: "Кросс-движения",
  d: "Нейрогимнастика, 8 мин",
  tag: "Нейро",
  done: true
}, {
  id: 3,
  t: "Дыхание диафрагмой",
  d: "Основа практики, 10 мин",
  tag: "Дыхание",
  done: false
}, {
  id: 4,
  t: "Таз и опора",
  d: "Женская гимнастика, 15 мин",
  tag: "Гимнастика",
  done: false
}, {
  id: 5,
  t: "Вечерний ритуал",
  d: "Расслабление, 9 мин",
  tag: "Лицо",
  done: false
}];
function StatusBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "var(--sp-3) var(--sp-5) 0",
      font: "var(--fw-semibold) 13px var(--font-body)",
      color: "var(--text-strong)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "9:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 6,
      opacity: .8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "signal",
    size: 14
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "wifi",
    size: 14
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "battery-full",
    size: 14
  })));
}
function TabBar({
  tab,
  onTab
}) {
  const items = [["home", "house", "Сегодня"], ["lessons", "list", "Практики"], ["diary", "book-open", "Дневник"], ["me", "user", "Я"]];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 0,
      padding: "var(--sp-2) var(--sp-3) var(--sp-4)",
      background: "var(--surface-glass)",
      backdropFilter: "var(--blur-glass)",
      borderTop: "1px solid var(--line-hairline)"
    }
  }, items.map(([k, ic, label]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => onTab(k),
    style: {
      border: 0,
      background: "transparent",
      cursor: "pointer",
      display: "grid",
      justifyItems: "center",
      gap: 4,
      minHeight: "var(--tap-min)",
      color: tab === k ? "var(--sakura-600)" : "var(--text-muted)",
      transition: "var(--t-color)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 20
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--fw-medium) 11px var(--font-body)"
    }
  }, label))));
}
function HomeScreen({
  onOpen
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--sp-5)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nuri-eyebrow"
  }, "\u0410\u0441\u0441\u0430\u043B\u044F\u043C\u0443 \u0430\u043B\u0435\u0439\u043A\u0443\u043C"), /*#__PURE__*/React.createElement("h3", {
    style: {
      marginTop: "var(--sp-2)"
    }
  }, "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u2014 \u0442\u0435\u043B\u043E \u0441\u043B\u0443\u0448\u0430\u0435\u043C")), /*#__PURE__*/React.createElement(Card, {
    variant: "silk",
    padding: "lg",
    interactive: true,
    onClick: () => onOpen(LESSONS[2])
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "dark"
  }, "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0434\u043D\u044F"), /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: "var(--sp-4) 0 var(--sp-2)"
    }
  }, "\u0414\u044B\u0445\u0430\u043D\u0438\u0435 \u0434\u0438\u0430\u0444\u0440\u0430\u0433\u043C\u043E\u0439"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: "var(--text-body-sm)",
      color: "var(--text-on-accent)"
    }
  }, "10 \u043C\u0438\u043D\u0443\u0442 \xB7 \u043B\u0435\u0436\u0430 \u0438\u043B\u0438 \u0441\u0438\u0434\u044F"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "dark",
    fullWidth: true,
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "play",
      size: 16
    })
  }, "\u041D\u0430\u0447\u0430\u0442\u044C"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-subtitle)",
      color: "var(--text-strong)"
    }
  }, "7"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-caption)",
      color: "var(--text-muted)"
    }
  }, "\u0434\u043D\u0435\u0439 \u043F\u043E\u0434\u0440\u044F\u0434")), /*#__PURE__*/React.createElement(Card, {
    padding: "md"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-subtitle)",
      color: "var(--text-strong)"
    }
  }, "2 / 48"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-caption)",
      color: "var(--text-muted)"
    }
  }, "\u0443\u0440\u043E\u043A\u043E\u0432 \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043E"))), /*#__PURE__*/React.createElement(AyahQuote, {
    translation: "\u0418 \u041E\u043D \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u043B \u043C\u0435\u0436\u0434\u0443 \u0432\u0430\u043C\u0438 \u043B\u044E\u0431\u043E\u0432\u044C \u0438 \u043C\u0438\u043B\u043E\u0441\u0435\u0440\u0434\u0438\u0435.",
    source: "\u0421\u0443\u0440\u0430 \u0410\u0440-\u0420\u0443\u043C, 21"
  }));
}
function LessonsScreen({
  onOpen
}) {
  const [filter, setFilter] = React.useState("Все");
  const tags = ["Все", "Лицо", "Нейро", "Дыхание", "Гимнастика"];
  const shown = filter === "Все" ? LESSONS : LESSONS.filter(l => l.tag === filter);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--sp-5)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement("h3", null, "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0438"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--gap-inline)",
      overflowX: "auto",
      paddingBottom: 4
    }
  }, tags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    selected: filter === t,
    onClick: () => setFilter(t)
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-3)"
    }
  }, shown.map(l => /*#__PURE__*/React.createElement(Card, {
    key: l.id,
    variant: "solid",
    padding: "md",
    interactive: true,
    onClick: () => onOpen(l)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 46,
      height: 46,
      flex: "none",
      borderRadius: "var(--radius-md)",
      background: "var(--grad-silk)",
      display: "grid",
      placeItems: "center",
      color: "var(--choco-700)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: l.done ? "check" : "play",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--fw-semibold) var(--fs-sm)/1.3 var(--font-body)",
      color: "var(--text-strong)"
    }
  }, l.t), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-body-sm)",
      color: "var(--text-muted)"
    }
  }, l.d)), l.done ? /*#__PURE__*/React.createElement(Badge, {
    tone: "success"
  }, "\u041F\u0440\u043E\u0439\u0434\u0435\u043D\u043E") : /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, l.tag))))));
}
function DiaryScreen() {
  const [tab, setTab] = React.useState("week");
  const days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
  const vals = [12, 8, 15, 0, 10, 20, 6];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--sp-5)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement("h3", null, "\u0414\u043D\u0435\u0432\u043D\u0438\u043A"), /*#__PURE__*/React.createElement(Tabs, {
    variant: "pill",
    items: [{
      value: "week",
      label: "Неделя"
    }, {
      value: "month",
      label: "Месяц"
    }],
    value: tab,
    onChange: setTab
  }), /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: "var(--sp-3)",
      height: 120
    }
  }, vals.map((v, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      display: "grid",
      justifyItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      height: Math.max(v * 4.5, 6),
      borderRadius: "var(--radius-sm)",
      background: v ? "var(--grad-accent)" : "var(--surface-sunken)",
      boxShadow: v ? "var(--shadow-xs)" : "none"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-caption)",
      color: "var(--text-muted)"
    }
  }, days[i]))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-3)"
    }
  }, [["Шея и плечи", "вчера · 12 мин"], ["Кросс-движения", "2 дня назад · 8 мин"]].map(([t, d]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-3)",
      padding: "var(--sp-3) 0",
      borderBottom: "1px solid var(--line-hairline)"
    }
  }, /*#__PURE__*/React.createElement(PearlBullet, null), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--fw-medium) var(--fs-sm) var(--font-body)",
      color: "var(--text-strong)"
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-caption)",
      fontWeight: 400,
      color: "var(--text-muted)"
    }
  }, d))))));
}
function MeScreen() {
  const [rem, setRem] = React.useState(true);
  const [quiet, setQuiet] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--sp-5)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 64,
      borderRadius: "var(--radius-pearl)",
      background: "var(--grad-pearl)",
      boxShadow: "var(--pearl-shadow)"
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-subtitle)",
      color: "var(--text-strong)"
    }
  }, "\u0410\u043C\u0438\u043D\u0430"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-caption)",
      color: "var(--text-muted)"
    }
  }, "\u0413\u043E\u0434\u043E\u0432\u043E\u0439 \u0434\u043E\u0441\u0442\u0443\u043F \xB7 \u0434\u043E 09.2027"))), /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "\u041D\u0430\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u044F \u043E \u043F\u0440\u0430\u043A\u0442\u0438\u043A\u0435",
    checked: rem,
    onChange: e => setRem(e.target.checked)
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "\u0422\u0438\u0445\u0438\u0439 \u0440\u0435\u0436\u0438\u043C \u0432 \u043D\u0430\u043C\u0430\u0437",
    checked: quiet,
    onChange: e => setQuiet(e.target.checked)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-2)"
    }
  }, [["Чат с наставницей", "message-circle"], ["Мои сохранённые", "bookmark"], ["Поддержка", "life-buoy"]].map(([t, ic]) => /*#__PURE__*/React.createElement("button", {
    key: t,
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-4)",
      minHeight: "var(--tap-min)",
      padding: "0 var(--sp-2)",
      border: 0,
      background: "transparent",
      cursor: "pointer",
      font: "var(--text-body-sm)",
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--aloewood-600)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 18
  })), t, /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: "auto",
      color: "var(--milktea-300)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 16
  }))))));
}
function PlayerScreen({
  lesson,
  onBack,
  onDone
}) {
  const [playing, setPlaying] = React.useState(true);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 300,
      backgroundImage: "url(../../assets/imagery/roses-pearls-gold.jpg)",
      backgroundSize: "cover",
      backgroundPosition: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--grad-veil)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "var(--sp-4)",
      left: "var(--sp-4)",
      right: "var(--sp-4)",
      display: "flex",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    name: "chevron-left",
    variant: "glass",
    label: "\u041D\u0430\u0437\u0430\u0434",
    onClick: onBack
  }), /*#__PURE__*/React.createElement(IconButton, {
    name: "bookmark",
    variant: "glass",
    label: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: "var(--sp-5)",
      right: "var(--sp-5)",
      bottom: "var(--sp-5)",
      color: "var(--pearl-100)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-eyebrow)",
      letterSpacing: "var(--ls-caps)",
      textTransform: "uppercase",
      color: "var(--mistyrose-300)"
    }
  }, lesson.tag), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-title)",
      marginTop: "var(--sp-2)"
    }
  }, lesson.t))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--sp-5)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-5)",
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      borderRadius: "var(--radius-pill)",
      background: "var(--surface-sunken)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "38%",
      height: "100%",
      background: "var(--grad-accent)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      font: "var(--text-caption)",
      color: "var(--text-muted)",
      marginTop: "var(--sp-2)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "3:48"), /*#__PURE__*/React.createElement("span", null, "10:00"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    name: "rotate-ccw",
    label: "\u041D\u0430\u0437\u0430\u0434 10 \u0441\u0435\u043A\u0443\u043D\u0434"
  }), /*#__PURE__*/React.createElement(IconButton, {
    name: playing ? "pause" : "play",
    size: "lg",
    variant: "primary",
    label: "\u041F\u0430\u0443\u0437\u0430",
    onClick: () => setPlaying(!playing)
  }), /*#__PURE__*/React.createElement(Tooltip, {
    content: "\u041E\u0442\u043C\u0435\u0442\u0438\u0442\u044C \u043F\u0440\u043E\u0439\u0434\u0435\u043D\u043D\u044B\u043C"
  }, /*#__PURE__*/React.createElement(IconButton, {
    name: "check",
    label: "\u0413\u043E\u0442\u043E\u0432\u043E",
    onClick: onDone
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nuri-eyebrow"
  }, "\u0427\u0442\u043E \u0434\u0435\u043B\u0430\u0435\u043C"), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: "var(--sp-3) 0 0",
      padding: 0,
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-3)"
    }
  }, ["Ладони на нижние рёбра, вдох в стороны", "Выдох дольше вдоха, без напряжения", "Шесть циклов, затем отдых"].map(t => /*#__PURE__*/React.createElement("li", {
    key: t,
    style: {
      display: "flex",
      gap: "var(--sp-3)",
      alignItems: "center",
      font: "var(--text-body-sm)",
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement(PearlBullet, {
    size: 10
  }), t))))));
}
function App() {
  const [tab, setTab] = React.useState("home");
  const [lesson, setLesson] = React.useState(null);
  const [toast, setToast] = React.useState(false);
  const screens = {
    home: /*#__PURE__*/React.createElement(HomeScreen, {
      onOpen: setLesson
    }),
    lessons: /*#__PURE__*/React.createElement(LessonsScreen, {
      onOpen: setLesson
    }),
    diary: /*#__PURE__*/React.createElement(DiaryScreen, null),
    me: /*#__PURE__*/React.createElement(MeScreen, null)
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      height: 844,
      margin: "0 auto",
      position: "relative",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      background: "var(--grad-page)",
      borderRadius: 44,
      border: "1px solid var(--line-soft)",
      boxShadow: "var(--shadow-lg)"
    }
  }, !lesson && /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto"
    }
  }, lesson ? /*#__PURE__*/React.createElement(PlayerScreen, {
    lesson: lesson,
    onBack: () => setLesson(null),
    onDone: () => {
      setLesson(null);
      setToast(true);
      setTimeout(() => setToast(false), 3000);
    }
  }) : screens[tab]), !lesson && /*#__PURE__*/React.createElement(TabBar, {
    tab: tab,
    onTab: setTab
  }), toast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: "var(--sp-4)",
      right: "var(--sp-4)",
      top: "var(--sp-6)",
      zIndex: 30
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "success",
    title: "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430",
    message: "\u041E\u0442\u043C\u0435\u0447\u0435\u043D\u043E \u0432 \u0434\u043D\u0435\u0432\u043D\u0438\u043A\u0435.",
    onClose: () => setToast(false)
  })));
}
Object.assign(window, {
  App,
  HomeScreen,
  LessonsScreen,
  DiaryScreen,
  MeScreen,
  PlayerScreen,
  TabBar,
  StatusBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Site.jsx
try { (() => {
const {
  Button,
  IconButton,
  Card,
  Badge,
  Tag,
  Icon,
  PearlBullet,
  SilkDivider,
  AyahQuote,
  Tabs,
  Input,
  Checkbox,
  Dialog,
  Toast
} = window.Ds_aa95d3;
function SiteHeader({
  onEnroll
}) {
  const links = ["Практики", "Курсы", "О Нури", "Отзывы"];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 20,
      background: "var(--surface-glass)",
      backdropFilter: "var(--blur-glass)",
      borderBottom: "1px solid var(--line-hairline)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-xl)",
      margin: "0 auto",
      padding: "var(--sp-4) var(--sp-6)",
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 26,
      color: "var(--text-strong)",
      letterSpacing: "-.02em",
      lineHeight: 1
    }
  }, "\u041D\u0443\u0440\u0438", /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-eyebrow)",
      letterSpacing: "var(--ls-caps)",
      textTransform: "uppercase",
      color: "var(--aloewood-600)",
      marginTop: 4
    }
  }, "\u043E \u0436\u0435\u043D\u0441\u043A\u043E\u043C")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: "var(--sp-6)",
      marginLeft: "auto"
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      font: "var(--text-body-sm)",
      textDecoration: "none"
    }
  }, l))), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: onEnroll
  }, "\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C\u0441\u044F")));
}
function Hero({
  onEnroll
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      overflow: "hidden",
      background: "var(--grad-silk)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      backgroundImage: "url(../../assets/textures/silk-rose-wave.webp)",
      backgroundSize: "cover",
      backgroundPosition: "center",
      opacity: 0.45,
      mixBlendMode: "soft-light"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      right: "6%",
      top: "12%",
      opacity: 0.5
    }
  }, /*#__PURE__*/React.createElement(PearlBullet, {
    size: 120,
    floating: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: "4%",
      bottom: "18%",
      opacity: 0.35
    }
  }, /*#__PURE__*/React.createElement(PearlBullet, {
    size: 56,
    floating: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: "var(--container-lg)",
      margin: "0 auto",
      padding: "var(--sp-9) var(--sp-6) var(--sp-10)",
      display: "grid",
      gridTemplateColumns: "minmax(0,1.1fr) minmax(0,.9fr)",
      gap: "var(--sp-8)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nuri-eyebrow"
  }, "\u0417\u0430\u0431\u043E\u0442\u0430 \u043E \u0441\u0435\u0431\u0435 \xB7 \u0447\u0435\u0440\u0435\u0437 \u043F\u0440\u0438\u0437\u043C\u0443 \u0418\u0441\u043B\u0430\u043C\u0430"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "var(--sp-4) 0 var(--sp-5)"
    }
  }, "\u041C\u044F\u0433\u043A\u0430\u044F \u0441\u0438\u043B\u0430", /*#__PURE__*/React.createElement("br", null), "\u0436\u0435\u043D\u0441\u043A\u043E\u0433\u043E \u0442\u0435\u043B\u0430"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-lead)",
      color: "var(--text-body)",
      maxWidth: 480
    }
  }, "\u0421\u0430\u043C\u043E\u043C\u0430\u0441\u0441\u0430\u0436 \u0447\u0435\u0440\u0435\u0437 \u0431\u0438\u043E\u043C\u0435\u0445\u0430\u043D\u0438\u043A\u0443, \u043D\u0435\u0439\u0440\u043E\u0433\u0438\u043C\u043D\u0430\u0441\u0442\u0438\u043A\u0430 \u0438 \u0436\u0435\u043D\u0441\u043A\u0430\u044F \u0433\u0438\u043C\u043D\u0430\u0441\u0442\u0438\u043A\u0430. \u0414\u0432\u0430\u0434\u0446\u0430\u0442\u044C \u043C\u0438\u043D\u0443\u0442 \u0432 \u0434\u0435\u043D\u044C \u2014 \u0434\u043B\u044F \u0442\u0435\u043B\u0430, \u0434\u044B\u0445\u0430\u043D\u0438\u044F \u0438 \u0441\u043F\u043E\u043A\u043E\u0439\u0441\u0442\u0432\u0438\u044F."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--gap-inline)",
      flexWrap: "wrap",
      marginTop: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    onClick: onEnroll,
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "sparkles",
      size: 18
    })
  }, "\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C\u0441\u044F \u043D\u0430 \u043A\u0443\u0440\u0441"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "secondary",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "play",
      size: 16
    })
  }, "\u041F\u0440\u043E\u0431\u043D\u044B\u0439 \u0443\u0440\u043E\u043A")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--sp-6)",
      marginTop: "var(--sp-7)"
    }
  }, [["2 400", "участниц"], ["48", "уроков"], ["20 мин", "в день"]].map(([n, l]) => /*#__PURE__*/React.createElement("div", {
    key: l
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-subtitle)",
      color: "var(--text-strong)"
    }
  }, n), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-caption)",
      color: "var(--aloewood-600)"
    }
  }, l))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/imagery/pearl-shell-beach.png",
    alt: "",
    style: {
      width: "100%",
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-lg)",
      display: "block"
    }
  }), /*#__PURE__*/React.createElement(Card, {
    padding: "sm",
    style: {
      position: "absolute",
      left: "-8%",
      bottom: "8%",
      width: 220
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--sp-3)"
    }
  }, /*#__PURE__*/React.createElement(PearlBullet, {
    size: 22
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-caption)",
      color: "var(--text-strong)"
    }
  }, "\u041F\u0440\u0430\u043A\u0442\u0438\u043A\u0430 \u0434\u043D\u044F"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-caption)",
      fontWeight: 400,
      color: "var(--text-muted)"
    }
  }, "\u0428\u0435\u044F \u0438 \u043F\u043B\u0435\u0447\u0438 \xB7 12 \u043C\u0438\u043D")))))), /*#__PURE__*/React.createElement(SilkDivider, {
    variant: "wave",
    color: "var(--pearl-100)"
  }));
}
function Practices() {
  const [tab, setTab] = React.useState("all");
  const items = [{
    k: "face",
    icon: "hand-heart",
    t: "Самомассаж лица",
    d: "Биомеханика мягких тканей: скулы, челюсть, шея.",
    n: "12 уроков"
  }, {
    k: "neuro",
    icon: "activity",
    t: "Нейрогимнастика",
    d: "Простые связки движений для ясной головы.",
    n: "9 уроков"
  }, {
    k: "gym",
    icon: "flower-2",
    t: "Женская гимнастика",
    d: "Таз, дыхание, осанка — мягко и без надрыва.",
    n: "18 уроков"
  }, {
    k: "face",
    icon: "moon-star",
    t: "Вечерний ритуал",
    d: "Расслабление перед сном и намазом.",
    n: "6 уроков"
  }, {
    k: "neuro",
    icon: "clock",
    t: "Пять минут",
    d: "Короткие практики между делами.",
    n: "14 уроков"
  }, {
    k: "gym",
    icon: "book-open",
    t: "Дыхание",
    d: "Диафрагма, ритм, тишина.",
    n: "8 уроков"
  }];
  const shown = tab === "all" ? items : items.filter(i => i.k === tab);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--pearl-100)",
      padding: "var(--sp-9) var(--sp-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: "var(--sp-5)",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nuri-eyebrow"
  }, "\u041D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F"), /*#__PURE__*/React.createElement("h2", {
    style: {
      marginTop: "var(--sp-3)"
    }
  }, "\u0422\u0440\u0438 \u043F\u0443\u0442\u0438 \u043A \u0442\u0435\u043B\u0443")), /*#__PURE__*/React.createElement(Tabs, {
    items: [{
      value: "all",
      label: "Все"
    }, {
      value: "face",
      label: "Лицо"
    }, {
      value: "neuro",
      label: "Нейро"
    }, {
      value: "gym",
      label: "Гимнастика"
    }],
    value: tab,
    onChange: setTab
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))",
      gap: "var(--gap-card)",
      marginTop: "var(--sp-6)"
    }
  }, shown.map(i => /*#__PURE__*/React.createElement(Card, {
    key: i.t,
    interactive: true,
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--aloewood-600)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i.icon,
    size: 24
  })), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, i.n)), /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: "var(--sp-4) 0 var(--sp-2)"
    }
  }, i.t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: "var(--text-body-sm)",
      color: "var(--text-muted)"
    }
  }, i.d))))));
}
function VerseBand() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--grad-silk-deep)",
      padding: "var(--sp-9) var(--sp-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-md)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement(AyahQuote, {
    tone: "dark",
    arabic: "\u0648\u064E\u062C\u064E\u0639\u064E\u0644\u064E \u0628\u064E\u064A\u0652\u0646\u064E\u0643\u064F\u0645 \u0645\u064E\u0651\u0648\u064E\u062F\u064E\u0651\u0629\u064B \u0648\u064E\u0631\u064E\u062D\u0652\u0645\u064E\u0629\u064B",
    translation: "\u0418 \u041E\u043D \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u043B \u043C\u0435\u0436\u0434\u0443 \u0432\u0430\u043C\u0438 \u043B\u044E\u0431\u043E\u0432\u044C \u0438 \u043C\u0438\u043B\u043E\u0441\u0435\u0440\u0434\u0438\u0435.",
    source: "\u0421\u0443\u0440\u0430 \u0410\u0440-\u0420\u0443\u043C, 21"
  })));
}
function Program() {
  const rows = [["Неделя 1", "Дыхание и опора", "Учимся дышать диафрагмой, ставим таз и стопы."], ["Неделя 2", "Шея и лицо", "Снимаем зажимы челюсти, работаем со скулами."], ["Неделя 3", "Нейросвязки", "Кросс-движения, координация, ясность."], ["Неделя 4", "Свой ритм", "Собираем личную практику на 20 минут."]];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--pearl-100)",
      padding: "var(--sp-9) var(--sp-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-md)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nuri-eyebrow"
  }, "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430"), /*#__PURE__*/React.createElement("h2", {
    style: {
      marginTop: "var(--sp-3)",
      marginBottom: "var(--sp-6)"
    }
  }, "\u0427\u0435\u0442\u044B\u0440\u0435 \u043D\u0435\u0434\u0435\u043B\u0438"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-4)"
    }
  }, rows.map(([w, t, d]) => /*#__PURE__*/React.createElement("div", {
    key: w,
    style: {
      display: "grid",
      gridTemplateColumns: "auto 120px minmax(0,1fr)",
      gap: "var(--sp-5)",
      alignItems: "start",
      padding: "var(--sp-4) 0",
      borderTop: "1px solid var(--line-hairline)"
    }
  }, /*#__PURE__*/React.createElement(PearlBullet, {
    size: 14,
    style: {
      marginTop: 8
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-caption)",
      letterSpacing: "var(--ls-caps)",
      textTransform: "uppercase",
      color: "var(--aloewood-600)",
      paddingTop: 4
    }
  }, w), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-subtitle)",
      color: "var(--text-strong)"
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-body-sm)",
      color: "var(--text-muted)"
    }
  }, d)))))));
}
function Pricing({
  onEnroll
}) {
  const [plan, setPlan] = React.useState("year");
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-sunken)",
      padding: "var(--sp-9) var(--sp-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nuri-eyebrow"
  }, "\u0423\u0447\u0430\u0441\u0442\u0438\u0435"), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: "var(--sp-3) 0 var(--sp-6)"
    }
  }, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0438\u0442\u043C"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))",
      gap: "var(--gap-card)",
      textAlign: "left"
    }
  }, [["month", "Месяц", "1 900 ₽", ["Все практики месяца", "Дневник практик", "Чат с наставницей"]], ["year", "Год", "14 900 ₽", ["Все 48 уроков", "Живые созвоны раз в месяц", "Разбор осанки по видео", "Доступ навсегда"]], ["gift", "В подарок", "2 400 ₽", ["Сертификат на месяц", "Открытка на почту"]]].map(([k, t, p, list]) => /*#__PURE__*/React.createElement(Card, {
    key: k,
    variant: plan === k ? "silk" : "pearl",
    padding: "lg",
    interactive: true,
    onClick: () => setPlan(k)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-subtitle)",
      color: "var(--text-strong)"
    }
  }, t), k === "year" && /*#__PURE__*/React.createElement(Badge, {
    tone: "gold"
  }, "\u0412\u044B\u0433\u043E\u0434\u043D\u043E")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 40,
      color: "var(--text-strong)",
      margin: "var(--sp-3) 0 var(--sp-4)"
    }
  }, p), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 0,
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-3)"
    }
  }, list.map(l => /*#__PURE__*/React.createElement("li", {
    key: l,
    style: {
      display: "flex",
      gap: "var(--sp-3)",
      alignItems: "center",
      font: "var(--text-body-sm)",
      color: plan === k ? "var(--text-on-accent)" : "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement(PearlBullet, {
    size: 10
  }), l))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--sp-5)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    variant: plan === k ? "dark" : "secondary",
    onClick: onEnroll
  }, "\u0412\u044B\u0431\u0440\u0430\u0442\u044C")))))));
}
function SiteFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--grad-dark)",
      color: "var(--text-on-dark)",
      padding: "var(--sp-8) var(--sp-6) var(--sp-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))",
      gap: "var(--sp-6)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 26
    }
  }, "\u041D\u0443\u0440\u0438"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-body-sm)",
      color: "var(--mistyrose-300)",
      marginTop: "var(--sp-2)"
    }
  }, "\u041E \u0436\u0435\u043D\u0441\u043A\u043E\u043C. \u0417\u0430\u0431\u043E\u0442\u0430 \u043E \u0441\u0435\u0431\u0435.")), [["Практики", ["Лицо", "Осанка", "Дыхание"]], ["Курсы", ["Четыре недели", "Пробный урок", "Подарочный сертификат"]], ["Связь", ["Telegram", "Instagram", "hello@nuri.ru"]]].map(([t, list]) => /*#__PURE__*/React.createElement("div", {
    key: t
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-eyebrow)",
      letterSpacing: "var(--ls-caps)",
      textTransform: "uppercase",
      color: "var(--gold-soft)"
    }
  }, t), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-2)",
      marginTop: "var(--sp-3)"
    }
  }, list.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      font: "var(--text-body-sm)",
      color: "var(--mistyrose-200)",
      textDecoration: "none"
    }
  }, l)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-lg)",
      margin: "var(--sp-6) auto 0",
      paddingTop: "var(--sp-4)",
      borderTop: "1px solid rgba(201,168,118,.3)",
      font: "var(--text-caption)",
      fontWeight: 400,
      color: "var(--milktea-300)"
    }
  }, "\xA9 2026 \u041D\u0443\u0440\u0438"));
}
function EnrollDialog({
  open,
  onClose,
  onDone
}) {
  const [ok, setOk] = React.useState(true);
  return /*#__PURE__*/React.createElement(Dialog, {
    open: open,
    title: "\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C\u0441\u044F \u043D\u0430 \u043A\u0443\u0440\u0441",
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: onClose
    }, "\u041F\u043E\u0437\u0436\u0435"), /*#__PURE__*/React.createElement(Button, {
      onClick: onDone,
      disabled: !ok
    }, "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--sp-4)"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "\u0412\u0430\u0448\u0435 \u0438\u043C\u044F",
    placeholder: "\u041D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, \u0410\u043C\u0438\u043D\u0430"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Telegram \u0438\u043B\u0438 email",
    placeholder: "@nick"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "\u0421\u043E\u0433\u043B\u0430\u0441\u043D\u0430 \u043D\u0430 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0443 \u0434\u0430\u043D\u043D\u044B\u0445",
    checked: ok,
    onChange: e => setOk(e.target.checked)
  })));
}
function Site() {
  const [dialog, setDialog] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      minHeight: "100%"
    }
  }, /*#__PURE__*/React.createElement(SiteHeader, {
    onEnroll: () => setDialog(true)
  }), /*#__PURE__*/React.createElement(Hero, {
    onEnroll: () => setDialog(true)
  }), /*#__PURE__*/React.createElement(Practices, null), /*#__PURE__*/React.createElement(VerseBand, null), /*#__PURE__*/React.createElement(Program, null), /*#__PURE__*/React.createElement(Pricing, {
    onEnroll: () => setDialog(true)
  }), /*#__PURE__*/React.createElement(SiteFooter, null), /*#__PURE__*/React.createElement(EnrollDialog, {
    open: dialog,
    onClose: () => setDialog(false),
    onDone: () => {
      setDialog(false);
      setToast(true);
      setTimeout(() => setToast(false), 3200);
    }
  }), toast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      right: "var(--sp-5)",
      bottom: "var(--sp-5)",
      zIndex: 50
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "success",
    title: "\u0417\u0430\u044F\u0432\u043A\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0430",
    message: "\u041D\u0430\u043F\u0438\u0448\u0435\u043C \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u0434\u043D\u044F, \u0438\u043D \u0448\u0430 \u0410\u043B\u043B\u0430\u0445.",
    onClose: () => setToast(false)
  })));
}
Object.assign(window, {
  Site,
  SiteHeader,
  Hero,
  Practices,
  VerseBand,
  Program,
  Pricing,
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Site.jsx", error: String((e && e.message) || e) }); }

__ds_ns.AyahQuote = __ds_scope.AyahQuote;

__ds_ns.PearlBullet = __ds_scope.PearlBullet;

__ds_ns.SilkDivider = __ds_scope.SilkDivider;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
